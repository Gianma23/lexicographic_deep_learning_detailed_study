import optuna
from trial import opt_trial_cf10, opt_trial_cf100
from optuna.trial import TrialState

if __name__ == "__main__":

    study = optuna.create_study(direction="maximize")
    study.optimize(opt_trial_cf100, n_trials=30, timeout=90000)
    pruned_trials = study.get_trials(deepcopy=False, states=[TrialState.PRUNED])
    complete_trials = study.get_trials(deepcopy=False, states=[TrialState.COMPLETE])
    complete_trials.sort(key=lambda x: x.value, reverse=True)

    print("Study statistics: ")
    print("  Number of finished trials: ", len(study.trials))
    print("  Number of pruned trials: ", len(pruned_trials))
    print("  Number of complete trials: ", len(complete_trials))