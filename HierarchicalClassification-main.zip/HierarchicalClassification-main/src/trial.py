from datasets import CIFAR100, CIFAR10
from hdcapsnet_cf100 import HD_CAPSNET_NS_CF100, HD_CAPSNET_NS_CF100_HALF, EarlyStopper, HD_CAPSNET_NS_CF100_NORELU
from torch.utils.data import DataLoader
from tqdm import tqdm
from metrics import hmeasurements

import torchvision.transforms as T
import torch, torch.nn as nn
import utils, config, numpy as np, random, os, statistics, matplotlib.pyplot as plt, sys
import optuna

seed = 2
np.random.seed(seed)
random.seed(seed)
torch.manual_seed(seed)
torch.cuda.manual_seed(seed)
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False
os.environ["PYTHONHASHSEED"] = str(seed)

train_params = config.CIFAR10_TRAIN_PARAMS
model_params = config.CIFAR10_MODEL_PARAMS
transform = config.CIFAR100_TRANSFORM
loss_weights = config.CIFAR100_LOSS_W

dataset = CIFAR100()
num_classes = utils.num_classes(dataset)
train_epochs = 30
early_stopper = EarlyStopper(patience=3, min_delta=10)
loss_type = "SEPARATE"
dw = False

def opt_trial_cf100(trial):

    lr = trial.suggest_float("lr", 1e-6, 1e-2, log=True)
    path = "Images/CIFAR100/"
    filename = f"HD-CNN-OPTUNA-{lr}"

    perm = torch.randperm(dataset['x_train'].shape[0])
    n_train = int(0.8 * dataset['x_train'].shape[0])
    train_idx = perm[:n_train]
    val_idx = perm[n_train:]

    dataset_tr = utils.ThreeLevelDataset_CIFAR100(
        images=dataset['x_train'].permute(0, 3, 1, 2)[train_idx],
        y_coarse=dataset['y_train_coarse'][train_idx],
        y_medium=dataset['y_train_medium'][train_idx],
        y_fine=dataset['y_train_fine'][train_idx],
        transform=transform
    )

    #dataset_tr = utils.ThreeLevelDataset_CIFAR100(
    #    images=dataset['x_train'].permute(0, 3, 1, 2),
    #    y_coarse=dataset['y_train_coarse'],
    #    y_medium=dataset['y_train_medium'],
    #    y_fine=dataset['y_train_fine'],
    #    transform=transform
    #)

    dataset_va = utils.ThreeLevelDataset_CIFAR100(
        images=dataset['x_train'].permute(0, 3, 1, 2)[val_idx],
        y_coarse=dataset['y_train_coarse'][val_idx],
        y_medium=dataset['y_train_medium'][val_idx],
        y_fine=dataset['y_train_fine'][val_idx],
        transform=T.Compose([
            T.ToTensor(),
            T.Normalize(mean=config.CIFAR100_MEAN, std=config.CIFAR100_STD),
        ])
    )

    setup = utils.get_pytorch_setup_optuna(HD_CAPSNET_NS_CF100, num_classes, model_params, train_params, loss_weights, dataset_tr, True, lr)
    c_to_m, m_to_f = utils.strange(num_classes, dataset)

    model = setup["model"].to("cuda:0")
    optimizer = setup["optimizer"]
    lr_scheduler = setup["lr_scheduler"]
    criterion = setup["class_loss_fn"]
    lw = setup["loss_weights"]
    init_lw = setup["loss_weights"]

    loader_tr = DataLoader(
        dataset_tr,
        batch_size= 64,
        shuffle=True,
        num_workers=0,
        pin_memory=True,
    )

    loader_va = DataLoader(
        dataset_va,
        batch_size= 64,
        shuffle=True,
        num_workers=0,
        pin_memory=True,
    )

    dataset_te = utils.ThreeLevelDataset_CIFAR100(
        images=dataset['x_test'].permute(0,3,1,2),
        y_coarse=dataset['y_test_coarse'],
        y_medium=dataset['y_test_medium'],
        y_fine=dataset['y_test_fine'],
        transform=T.Compose([
            T.ToTensor(),
            T.Normalize(mean=config.CIFAR100_MEAN, std=config.CIFAR100_STD),
        ])
    )

    loader_te = DataLoader(
        dataset_te,
        batch_size= 64,
        shuffle=True,
        num_workers=0,
        pin_memory=True,
    )

    total_loss = [[],[],[]]
    val_total_loss = [[], [], []]
    val_total_acc = [[], [], []]
    completed_epochs = 0


    for epoch in tqdm(range(train_epochs)):
        coarse_pos, medium_pos, fine_pos = 0,0,0
        model.train()
        epoch_loss = [[],[],[]]
        val_loss = [[], [], []]
        for img, yc, ym, yf in loader_tr:

            img = img.to(device="cuda:0")
            yc, ym, yf = yc.to(device="cuda:0"), ym.to(device="cuda:0"), yf.to(device="cuda:0")

            img, yc, ym, yf = utils.mixup_data(img, yc, ym, yf)

            optimizer.zero_grad()
            coarse_pred, medium_pred, fine_pred = model(img)

            #loss = utils.CustomLoss(yc, ym, yf, coarse_pred, medium_pred, fine_pred, lw["coarse"], lw["medium"], lw["fine"], num_classes["medium"], num_classes["fine"], c_to_m, m_to_f)
            #loss_c, loss_m, loss_f = utils.CustomLoss2(yc, ym, yf, coarse_pred, medium_pred, fine_pred, lw["coarse"], lw["medium"], lw["fine"], num_classes["medium"], num_classes["fine"], c_to_m, m_to_f)
            loss_c = utils.margin_loss(yc, coarse_pred)
            loss_m = utils.margin_loss(ym, medium_pred)
            loss_f = utils.margin_loss(yf, fine_pred)

            epoch_loss[0].append(loss_c.item())
            epoch_loss[1].append(loss_m.item())
            epoch_loss[2].append(loss_f.item())

            if loss_type == "SINGLE": 

                loss = loss_c + loss_m + loss_f
                loss.backward()

            elif loss_type == "SEPARATE":
                #loss_c *= 1e-2
                #loss_m *= 1e-1
                loss_c.backward(retain_graph = True)
                loss_m.backward(retain_graph = True)
                loss_f.backward()

            else:
                raise Exception("WRONG LOSS TYPE")

            optimizer.step()
        #"""
        model.eval()
        labels = 0
        for img, yc, ym, yf in loader_va:

            img = img.to(device="cuda:0")
            yc, ym, yf = yc.to(device="cuda:0"), ym.to(device="cuda:0"), yf.to(device="cuda:0")

            coarse_pred, medium_pred, fine_pred = model(img)

            #loss_c, loss_m, loss_f = utils.CustomLoss2(yc, ym, yf, coarse_pred, medium_pred, fine_pred, lw["coarse"], lw["medium"], lw["fine"], num_classes["medium"], num_classes["fine"], c_to_m, m_to_f)
            loss_c = utils.margin_loss(yc, coarse_pred)
            loss_m = utils.margin_loss(ym, medium_pred)
            loss_f = utils.margin_loss(yf, fine_pred)

            c_pred, m_pred, f_pred = torch.argmax(coarse_pred, 1).to(dtype=torch.float), torch.argmax(medium_pred, 1).to(dtype=torch.float), torch.argmax(fine_pred, 1).to(dtype=torch.float)

            c_true, m_true, f_true = torch.argmax(yc, 1).to(dtype=torch.float), torch.argmax(ym, 1).to(dtype=torch.float), torch.argmax(yf, 1).to(dtype=torch.float)

            labels += len(c_true)

            val_loss[0].append(loss_c.item())
            val_loss[1].append(loss_m.item())
            val_loss[2].append(loss_f.item())

            for j, elem in enumerate(c_true):
                if elem == c_pred[j]:
                    coarse_pos += 1
            for j, elem in enumerate(m_true):
                if elem == m_pred[j]:
                    medium_pos += 1
            for j, elem in enumerate(f_true):
                if elem == f_pred[j]:
                    fine_pos += 1

            validation_loss = loss_c + loss_m + loss_f

        coarse_acc = 100*coarse_pos/labels
        medium_acc = 100*medium_pos/labels
        fine_acc = 100*fine_pos/labels

        if dw:
            new_LW = utils.lw_modifier(init_lw, [coarse_pos, medium_pos, fine_pos])

            lw["coarse"] = new_LW[0]
            lw["medium"] = new_LW[1]
            lw["fine"] = new_LW[2]

        #total_loss.append(statistics.mean(epoch_loss))
        total_loss[0].append(statistics.mean(epoch_loss[0]))
        total_loss[1].append(statistics.mean(epoch_loss[1]))
        total_loss[2].append(statistics.mean(epoch_loss[2]))

        val_total_loss[0].append(statistics.mean(val_loss[0]))
        val_total_loss[1].append(statistics.mean(val_loss[1]))
        val_total_loss[2].append(statistics.mean(val_loss[2]))

        val_total_acc[0].append(coarse_acc)
        val_total_acc[1].append(medium_acc)
        val_total_acc[2].append(fine_acc)
        completed_epochs += 1

        final_val_acc = (coarse_acc + medium_acc + fine_acc)/3.0

        trial.report(fine_acc, epoch)
        if trial.should_prune():
            raise optuna.exceptions.TrialPruned()

        lr_scheduler.step()

    return fine_acc


def opt_trial_cf10(trial):

    transform = config.CIFAR10_TRANSFORM
    loss_weights = config.CIFAR10_LOSS_W

    dataset = CIFAR10()
    num_classes = utils.num_classes(dataset)

    lr = trial.suggest_float("lr", 1e-6, 1e-2, log=True)

    perm = torch.randperm(dataset['x_train'].shape[0])
    n_train = int(0.8 * dataset['x_train'].shape[0])
    train_idx = perm[:n_train]
    val_idx = perm[n_train:]

    dataset_tr = utils.ThreeLevelDataset_CIFAR10(
        images=dataset['x_train'].permute(0, 3, 1, 2)[train_idx],
        y_coarse=dataset['y_train_coarse'][train_idx],
        y_medium=dataset['y_train_medium'][train_idx],
        y_fine=dataset['y_train_fine'][train_idx],
        transform=transform
    )

    dataset_va = utils.ThreeLevelDataset_CIFAR10(
        images=dataset['x_train'].permute(0, 3, 1, 2)[val_idx],
        y_coarse=dataset['y_train_coarse'][val_idx],
        y_medium=dataset['y_train_medium'][val_idx],
        y_fine=dataset['y_train_fine'][val_idx],
        transform=T.Compose([
            T.ToTensor(),
            T.Normalize(mean=config.CIFAR100_MEAN, std=config.CIFAR100_STD),
        ])
    )

    setup = utils.get_pytorch_setup_optuna(HD_CAPSNET_NS_CF100, num_classes, model_params, train_params, loss_weights, dataset_tr, True, lr)
    c_to_m, m_to_f = utils.strange(num_classes, dataset)

    model = setup["model"].to("cuda:0")
    optimizer = setup["optimizer"]
    lr_scheduler = setup["lr_scheduler"]
    criterion = setup["class_loss_fn"]
    lw = setup["loss_weights"]
    init_lw = setup["loss_weights"]

    loader_tr = DataLoader(
        dataset_tr,
        batch_size= 64,
        shuffle=True,
        num_workers=0,
        pin_memory=True,
    )

    loader_va = DataLoader(
        dataset_va,
        batch_size= 64,
        shuffle=True,
        num_workers=0,
        pin_memory=True,
    )

    dataset_te = utils.ThreeLevelDataset_CIFAR10(
        images=dataset['x_test'].permute(0,3,1,2),
        y_coarse=dataset['y_test_coarse'],
        y_medium=dataset['y_test_medium'],
        y_fine=dataset['y_test_fine'],
        transform=T.Compose([
            T.ToTensor(),
            T.Normalize(mean=config.CIFAR10_MEAN, std=config.CIFAR10_STD),
        ])
    )

    total_loss = [[],[],[]]
    val_total_loss = [[], [], []]
    val_total_acc = [[], [], []]
    completed_epochs = 0


    for epoch in tqdm(range(train_epochs)):
        coarse_pos, medium_pos, fine_pos = 0,0,0
        model.train()
        epoch_loss = [[],[],[]]
        val_loss = [[], [], []]
        for img, yc, ym, yf in loader_tr:

            img = img.to(device="cuda:0")
            yc, ym, yf = yc.to(device="cuda:0"), ym.to(device="cuda:0"), yf.to(device="cuda:0")

            img, yc, ym, yf = utils.mixup_data(img, yc, ym, yf)

            optimizer.zero_grad()
            coarse_pred, medium_pred, fine_pred = model(img)

            #loss = utils.CustomLoss(yc, ym, yf, coarse_pred, medium_pred, fine_pred, lw["coarse"], lw["medium"], lw["fine"], num_classes["medium"], num_classes["fine"], c_to_m, m_to_f)
            #loss_c, loss_m, loss_f = utils.CustomLoss2(yc, ym, yf, coarse_pred, medium_pred, fine_pred, lw["coarse"], lw["medium"], lw["fine"], num_classes["medium"], num_classes["fine"], c_to_m, m_to_f)
            loss_c = utils.margin_loss(yc, coarse_pred)
            loss_m = utils.margin_loss(ym, medium_pred)
            loss_f = utils.margin_loss(yf, fine_pred)

            epoch_loss[0].append(loss_c.item())
            epoch_loss[1].append(loss_m.item())
            epoch_loss[2].append(loss_f.item())

            if loss_type == "SINGLE": 

                loss = loss_c + loss_m + loss_f
                loss.backward()

            elif loss_type == "SEPARATE":
                #loss_c *= 1e-2
                #loss_m *= 1e-1
                loss_c.backward(retain_graph = True)
                loss_m.backward(retain_graph = True)
                loss_f.backward()

            else:
                raise Exception("WRONG LOSS TYPE")

            optimizer.step()
        #"""
        model.eval()
        labels = 0
        for img, yc, ym, yf in loader_va:

            img = img.to(device="cuda:0")
            yc, ym, yf = yc.to(device="cuda:0"), ym.to(device="cuda:0"), yf.to(device="cuda:0")

            coarse_pred, medium_pred, fine_pred = model(img)

            #loss_c, loss_m, loss_f = utils.CustomLoss2(yc, ym, yf, coarse_pred, medium_pred, fine_pred, lw["coarse"], lw["medium"], lw["fine"], num_classes["medium"], num_classes["fine"], c_to_m, m_to_f)
            loss_c = utils.margin_loss(yc, coarse_pred)
            loss_m = utils.margin_loss(ym, medium_pred)
            loss_f = utils.margin_loss(yf, fine_pred)

            c_pred, m_pred, f_pred = torch.argmax(coarse_pred, 1).to(dtype=torch.float), torch.argmax(medium_pred, 1).to(dtype=torch.float), torch.argmax(fine_pred, 1).to(dtype=torch.float)

            c_true, m_true, f_true = torch.argmax(yc, 1).to(dtype=torch.float), torch.argmax(ym, 1).to(dtype=torch.float), torch.argmax(yf, 1).to(dtype=torch.float)

            labels += len(c_true)

            val_loss[0].append(loss_c.item())
            val_loss[1].append(loss_m.item())
            val_loss[2].append(loss_f.item())

            for j, elem in enumerate(c_true):
                if elem == c_pred[j]:
                    coarse_pos += 1
            for j, elem in enumerate(m_true):
                if elem == m_pred[j]:
                    medium_pos += 1
            for j, elem in enumerate(f_true):
                if elem == f_pred[j]:
                    fine_pos += 1

            validation_loss = loss_c + loss_m + loss_f

        coarse_acc = 100*coarse_pos/labels
        medium_acc = 100*medium_pos/labels
        fine_acc = 100*fine_pos/labels

        if dw:
            new_LW = utils.lw_modifier(init_lw, [coarse_pos, medium_pos, fine_pos])

            lw["coarse"] = new_LW[0]
            lw["medium"] = new_LW[1]
            lw["fine"] = new_LW[2]

        #total_loss.append(statistics.mean(epoch_loss))
        total_loss[0].append(statistics.mean(epoch_loss[0]))
        total_loss[1].append(statistics.mean(epoch_loss[1]))
        total_loss[2].append(statistics.mean(epoch_loss[2]))

        val_total_loss[0].append(statistics.mean(val_loss[0]))
        val_total_loss[1].append(statistics.mean(val_loss[1]))
        val_total_loss[2].append(statistics.mean(val_loss[2]))

        val_total_acc[0].append(coarse_acc)
        val_total_acc[1].append(medium_acc)
        val_total_acc[2].append(fine_acc)
        completed_epochs += 1

        final_val_acc = (coarse_acc + medium_acc + fine_acc)/3.0

        trial.report(fine_acc, epoch)
        if trial.should_prune():
            raise optuna.exceptions.TrialPruned()

        lr_scheduler.step()

    return fine_acc