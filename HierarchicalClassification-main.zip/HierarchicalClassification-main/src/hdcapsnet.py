import torch
import torch.nn as nn
import numpy as np, math, sys
from torch.linalg import solve as solve_matrix_system

def squash(x, dim=-1, eps=1e-8):
    """
    non-linear squashing function to manipulate the length of the capsule vectors
    :param s: input tensor containing capsule vectors
    :param axis: If `axis` is a Python integer, the input is considered a batch of vectors,
      and `axis` determines the axis in `tensor` over which to compute squash.
    :return: a Tensor with same shape as input vectors
    """
    squared_norm = (x ** 2).sum(dim=dim, keepdim=True)
    scale = squared_norm / (1.0 + squared_norm)
    return scale * x / torch.sqrt(squared_norm + eps)

def safe_norm(x,
              axis = -1,
              keepdims = False,
              eps = None):
    """
    Safe computation of vector 2-norm
    :param s: input tensor
    :param axis: If `axis` is a Python integer, the input is considered a batch 
      of vectors, and `axis` determines the axis in `tensor` over which to 
      compute vector norms.
    :param keepdims: If True, the axis indicated in `axis` are kept with size 1.
      Otherwise, the dimensions in `axis` are removed from the output shape.
    :param name: The name of the op.
    :return: A `Tensor` of the same type as tensor, containing the vector norms. 
      If `keepdims` is True then the rank of output is equal to
      the rank of `tensor`. If `axis` is an integer, the rank of `output` is 
      one less than the rank of `tensor`.
    """
    if eps is None:
        eps = torch.finfo(x.dtype).eps

    squared_norm = torch.sum(x * x, dim=axis, keepdim=keepdims)
    return torch.sqrt(squared_norm + eps)

class MarginLoss(nn.Module):
    """ 
    Compute margin loss. 
    y_true shape [None, n_classes] 
    y_pred shape [None, num_capsule] = [None, n_classes] 

    """

    def __init__(self, m_plus: float = 0.9, m_minus: float = 0.1, lambda_: float = 0.5):
        super(MarginLoss, self).__init__()
        self.m_plus = m_plus
        self.m_minus = m_minus
        self.lambda_ = lambda_

    def forward(self, y_true: torch.Tensor, y_pred: torch.Tensor) -> torch.Tensor:
        # present error: max(0, m_plus − y_pred)^2
        present_error = torch.clamp(self.m_plus - y_pred, min=0.0) ** 2

        # absent error: max(0, y_pred − m_minus)^2
        absent_error = torch.clamp(y_pred - self.m_minus, min=0.0) ** 2

        # combine errors
        loss_per_class = (
            y_true * present_error
            + self.lambda_ * (1.0 - y_true) * absent_error
        )

        # sum over classes, then mean over batch
        loss = loss_per_class.sum(dim=1).mean()
        return loss


class Mask(torch.nn.Module):
    """
    Mask a Tensor with the label during training 
    and mask a Tensor with predicted lable during test/inference
    input shapes
      X shape = [None, num_capsule, dim_vector] 
      y_true shape = [None, num_capsule] 
      y_pred shape = [None, num_capsule]
    output shape = [None, num_capsule * dim_vector]
    """

    def __init__(self, n_caps, n_dims):
        super().__init__()
        self.n_caps = n_caps
        self.n_dims = n_dims

    def forward(self, input, training=None):
        X, y_true, y_proba = input
        if training:
            if isinstance(y_true, np.ndarray):
                reconstruction_mask = torch.from_numpy(y_true).float().to(device="cuda:0")
            else:
                reconstruction_mask = y_true
        else:
            y_proba_argmax = torch.argmax(y_proba, dim=1)
            y_pred = torch.nn.functional.one_hot(y_proba_argmax, num_classes=self.n_caps)
            reconstruction_mask = y_pred
        reconstruction_mask_reshaped = torch.reshape(
                                      reconstruction_mask, [-1, self.n_caps, 1])
        caps2_output_masked = torch.mul(
                            X, reconstruction_mask_reshaped)
        decoder_input = torch.reshape(caps2_output_masked,
                        [-1, self.n_caps * self.n_dims])
        return decoder_input

    def compute_output_shape(self, input_shape):
        return (None, input_shape[0][1] * input_shape[0][2])

class LengthLayer(torch.nn.Module):
    """
    Compute the length of capsule vectors.
    inputs: shape=[None, num_capsule, dim_vector]
    output: shape=[None, num_capsule]

    """
    def forward(self, X):
        y_proba = safe_norm(X, axis=-1)
        return y_proba
    
    def compute_output_shape(self, batch_input_shape): 
        return (batch_input_shape[0], batch_input_shape[1])


class SecondaryCapsule(torch.nn.Module):
    """
    The Secondary Capsule layer With Dynamic Routing Algorithm. 
    input shape = [None, input_num_capsule, input_dim_capsule] 
    output shape = [None, num_capsule, dim_capsule]
    :param n_caps: number of capsules in this layer
    :param n_dims: dimension of the output vectors of the capsules in this layer
    """
    def __init__(self, n_caps, n_dims, routings=2, in_caps = None, in_dim = None):
        super().__init__()
        self.n_caps = n_caps
        self.n_dims = n_dims
        self.routings = routings
        if in_caps is not None and in_dim is not None:
            w = torch.randn(1, in_caps, n_caps, n_dims, in_dim) * 0.1
            self.W = nn.Parameter(w)    # registered immediately
        else:
            self.W = None

    def forward(self, x : torch.Tensor):
        batch_size, in_caps, in_dim = x.size()
        #print(f"in_caps={in_caps}")
        #print(f"in_dim={in_dim}")

        W_tiled = self.W.tile(batch_size, 1, 1, 1, 1)
        caps1_output_expanded = x.unsqueeze(-1)
        caps1_output_tile = caps1_output_expanded.unsqueeze(2)
        caps1_output_tiled = caps1_output_tile.tile(1, 1, self.n_caps, 1, 1)
        caps2_predicted = torch.matmul(W_tiled, caps1_output_tiled)

        raw_weights = torch.zeros([batch_size, in_caps, self.n_caps, 1, 1], dtype=torch.float32).to(device="cuda:0")
        assert self.routings > 0

        for i in range(self.routings):
            soft = nn.Softmax(dim=2)
            routing_weights = soft(raw_weights)
            weighted_predictions = torch.multiply(routing_weights, caps2_predicted)
            weighted_sum = torch.sum(weighted_predictions, dim=1, keepdim=True, dtype=torch.float32)
            caps2_output_round_1 = squash(weighted_sum, dim=-2)
            caps2_output_squeezed = torch.squeeze(caps2_output_round_1, dim=(1,4))

            if i < self.routings - 1:
                caps2_output_round_1_tiled = torch.tile(caps2_output_round_1, [1, in_caps, 1, 1, 1])
                caps2_predicted_t = caps2_predicted.transpose(-1, -2)
                agreement = torch.matmul(caps2_predicted_t, caps2_output_round_1_tiled)
                raw_weights_round_2 = torch.add(raw_weights, agreement)
                raw_weights = raw_weights_round_2

        return caps2_output_squeezed

    def compute_output_shape(self, batch_input_shape):
        return (batch_input_shape[0], self.n_caps, self.n_dims)
    
    def get_config(self): ### custom layers to be serializable as part of a Functional model
        base_config = super().get_config()
        return {**base_config, 
                "n_caps": self.n_caps, 
                "n_dims": self.n_dims,
                "routings": self.routings}

class HD_CAPSNET(torch.nn.Module):

    def __init__(self, input_shape, no_coarse_classes = 2, no_medium_classes = 6, no_fine_classes = 10, PCap_n_dims = 8, SCap_n_dims = 16):
        super().__init__()

        self.n_coarse = no_coarse_classes
        self.n_medium = no_medium_classes
        self.n_fine = no_fine_classes
        self.Pcap_dim = PCap_n_dims
        self.Scap_dim = SCap_n_dims
        self.C, self.H, self.W = input_shape
        self.activation = torch.nn.ReLU()

        self.layer1 = nn.Conv2d(self.C, 64, 3, padding=1)
        self.layer2 = nn.BatchNorm2d(64)
        self.layer3 = nn.Conv2d(64, 64, 3, padding=1)
        self.layer4 = nn.BatchNorm2d(64)
        self.layer5 = nn.MaxPool2d(2, 2)

        self.layer6 = nn.Conv2d(64, 128, 3, padding=1)
        self.layer7 = nn.BatchNorm2d(128)
        self.layer8 = nn.Conv2d(128, 128, 3, padding=1)
        self.layer9 = nn.BatchNorm2d(128)
        self.layer10 = nn.MaxPool2d(2, 2)

        self.layer11 = nn.Conv2d(128, 256, 3, padding=1)
        self.layer12 = nn.BatchNorm2d(256)
        self.layer13 = nn.Conv2d(256, 256, 3, padding=1)
        self.layer14 = nn.BatchNorm2d(256)
        self.layer15 = nn.MaxPool2d(2, 2)

        self.layer16 = nn.Conv2d(256, 512, 3, padding=1)
        self.layer17 = nn.BatchNorm2d(512)
        self.layer18 = nn.Conv2d(512, 512, 3, padding=1)
        self.layer19 = nn.BatchNorm2d(512)
        self.layer20 = nn.MaxPool2d(2, 2)

        self.sec_f = SecondaryCapsule(self.n_fine, 8, 2, 38, 16)
        self.sec_m = SecondaryCapsule(self.n_medium, 16, 2, 18, 32)
        self.sec_c = SecondaryCapsule(self.n_coarse, 32, 2, 64, 8)

        self.predictor = LengthLayer()

    def forward(self, x):

        batchsize = x.size(0)
        x = x.to(device="cuda:0")

        z = self.layer1(x)
        if torch.isnan(z).any().item():
            print("AFTER LAYER1")
            print(torch.mean(x[1:]))
            sys.exit(12)
        z = self.activation(z)
        z = self.layer2(z)
        z = self.layer3(z)
        z = self.activation(z)
        z = self.layer4(z)
        z = self.layer5(z)

        z = self.layer6(z)
        z = self.activation(z)
        z = self.layer7(z)
        z = self.layer8(z)
        z = self.activation(z)
        z = self.layer9(z)
        z = self.layer10(z)

        z = self.layer11(z)
        z = self.activation(z)
        z = self.layer12(z)
        z = self.layer13(z)
        z = self.activation(z)
        z = self.layer14(z)
        z = self.layer15(z)

        z = self.layer16(z)
        z = self.activation(z)
        z = self.layer17(z)
        z = self.layer18(z)
        z = self.activation(z)
        z = self.layer19(z)
        z = self.layer20(z)




        #z = z.view(batchsize, math.prod(z.shape[1:])//self.Pcap_dim, self.Pcap_dim)
        z = z.view(batchsize, -1, self.Pcap_dim)
        p_caps_c = squash(z)
        sec_c = self.sec_c(p_caps_c)

        #p_caps_m = p_caps_c.view(batchsize, math.prod(p_caps_c.shape[1:])//sec_c.shape[-1], sec_c.shape[-1])
        p_caps_m = p_caps_c.view(batchsize, -1, sec_c.shape[-1])
        skip_m = torch.cat((p_caps_m, sec_c), dim=1)
        sec_m = self.sec_m(skip_m)

        #p_caps_f = p_caps_c.view(batchsize, math.prod(p_caps_m.shape[1:])//sec_m.shape[-1], sec_m.shape[-1])
        p_caps_f = p_caps_c.view(batchsize, -1, sec_m.shape[-1])
        skip_f = torch.cat((p_caps_f, sec_m), dim=1)
        sec_f = self.sec_f(skip_f)

        pred_c = self.predictor(sec_c)
        pred_m = self.predictor(sec_m)
        pred_f = self.predictor(sec_f)

        return pred_c, pred_m, pred_f
    


#############################################################################################################################################
#############################################################################################################################################
#############################################################################################################################################

class HD_CAPSNET_NS(torch.nn.Module):

    def __init__(self, input_shape, no_coarse_classes = 2, no_medium_classes = 6, no_fine_classes = 10, PCap_n_dims = 8, SCap_n_dims = 16, dataset = None, bias = False):
        super().__init__()

        self.n_coarse = no_coarse_classes
        self.n_medium = no_medium_classes
        self.n_fine = no_fine_classes
        self.Pcap_dim = PCap_n_dims
        self.Scap_dim = SCap_n_dims
        self.C, self.H, self.W = input_shape
        self.activation = torch.nn.ReLU()
        self.branch = 512
        self.lin_in = 128
        self.v = torch.tensor(0., device = "cuda:0")
        self.dataset = dataset

        self.c2_reinforcer = torch.empty((128, self.n_medium), device = "cuda:0")
        self.c3_reinforcer = torch.empty((128, self.n_fine), device = "cuda:0")

        self.layer1 = nn.Conv2d(self.C, 64, 3, padding=1, bias=bias)
        self.layer2 = nn.BatchNorm2d(64)
        self.layer3 = nn.Conv2d(64, 64, 3, padding=1, bias=bias)
        self.layer4 = nn.BatchNorm2d(64)
        self.layer5 = nn.MaxPool2d(2, 2)

        self.layer6 = nn.Conv2d(64, 128, 3, padding=1, bias=bias)
        self.layer7 = nn.BatchNorm2d(128)
        self.layer8 = nn.Conv2d(128, 128, 3, padding=1, bias=bias)
        self.layer9 = nn.BatchNorm2d(128)
        self.layer10 = nn.MaxPool2d(2, 2)

        self.layer11 = nn.Conv2d(128, 256, 3, padding=1, bias=bias)
        self.layer12 = nn.BatchNorm2d(256)
        self.layer13 = nn.Conv2d(256, 256, 3, padding=1, bias=bias)
        self.layer14 = nn.BatchNorm2d(256)
        self.layer15 = nn.MaxPool2d(2, 2)

        self.layer16 = nn.Conv2d(256, 512, 3, padding=1, bias=bias)
        self.layer17 = nn.BatchNorm2d(512)
        self.layer18 = nn.Conv2d(512, 512, 3, padding=1, bias=bias)
        self.layer19 = nn.BatchNorm2d(512)
        self.layer20 = nn.MaxPool2d(2, 2)

        #self.layerb_mid = nn.Linear(self.branch, self.lin_in)

        self.layer_b17 = nn.Linear(self.branch, self.n_coarse)
        self.layer_b27 = nn.Linear(self.branch, self.n_medium)
        self.layer_b37 = nn.Linear(self.branch, self.n_fine)

        self.I = torch.eye(self.branch, device = "cuda:0")
        self.I_1 = torch.eye(self.layer_b17.out_features, device="cuda:0")
        self.I_2 = torch.eye(self.layer_b17.out_features + self.layer_b27.out_features, device="cuda:0")

    def forward_branch(self, z):
        #z = self.layerb_mid(z)
        z = self.activation(z)

        return z
    
    def forward_conv(self, z):
        return z

    def c2_reinforce(self, c1_logits):
        return self.dataset.c2_reinforce(c1_logits - torch.max(c1_logits), self.c2_reinforcer)
    
    def c3_reinforce(self, c2_logits):
        return self.dataset.c3_reinforce(c2_logits - torch.max(c2_logits), self.c3_reinforcer)

    def layer_branch_2_final_reinforce(self, ort, prj, b1):
        return self.layer_b27(ort + prj) + self.c2_reinforce(b1.clone().detach())
    
    def layer_branch_3_final_reinforce(self, ort, prj, b2):
        return self.layer_b37(ort + prj) + self.c3_reinforce(b2.clone().detach())

    

    def project(self, z): # https://math.stackexchange.com/questions/4021915/projection-orthogonal-to-two-vectors

        #start_time = time()
        W1 = self.layer_b17.weight.clone().detach()
        W2 = self.layer_b27.weight.clone().detach()
        ort2 = torch.empty_like(z)
        ort3 = torch.empty_like(z)

        zz = z.clone().detach()

        mask = torch.heaviside(zz, self.v)
        Rk = torch.einsum('ij, jh -> ijh', mask, self.I)
        W1k = W1.matmul(Rk)
        W2k_ = W2.matmul(Rk)
        W2k = torch.cat((W1k, W2k_), dim = 1)

        ort2 = self.compute_orthogonal(z, W1k, self.I_1)
        ort3 = self.compute_orthogonal(z, W2k, self.I_2)

        self.ort2 = ort2.clone().detach()
        self.ort3 = ort3.clone().detach()

        prj2 = zz - self.ort2
        prj3 = zz - self.ort3
        #print(f"project operation took: {time() - start_time} seconds")
        return ort2, ort3, prj2, prj3

    def compute_orthogonal(self, z, W, I_o = None, eps = 1e-8):
        WWT = torch.matmul(W, W.mT)

        P = solve_matrix_system((WWT + eps), I_o) # IN CASE ADD EPS
        P = torch.matmul(P, W)

        P = self.I - torch.matmul(W.mT, P) # Broadcasting

        return torch.matmul(z.unsqueeze(1), P).squeeze()

    def forward(self, x):

        batchsize = x.size(0)
        x = x.to(device="cuda:0")

        z = self.layer1(x)
        z = self.activation(z)
        z = self.layer2(z)
        z = self.layer3(z)
        z = self.activation(z)
        z = self.layer4(z)
        z = self.layer5(z)

        z = self.layer6(z)
        z = self.activation(z)
        z = self.layer7(z)
        z = self.layer8(z)
        z = self.activation(z)        
        z = self.layer9(z)
        z = self.layer10(z)

        z = self.layer11(z)
        z = self.activation(z)
        z = self.layer12(z)
        z = self.layer13(z)
        z = self.activation(z)
        z = self.layer14(z)
        z = self.layer15(z)

        z = self.layer16(z)
        z = self.activation(z)        
        z = self.layer17(z)
        z = self.layer18(z)
        z = self.activation(z)        
        z = self.layer19(z)
        z = self.layer20(z)

        z = self.forward_conv(z)

        z = torch.flatten(z, start_dim = 1)

        z = self.forward_branch(z)

        ort2, ort3, prj2, prj3 = self.project(z)

		# branch 1
        b1 = self.layer_b17(z)
		
		# branch 2
        b2 = self.layer_branch_2_final_reinforce(ort2, prj2, b1)
        #b2 = self.layer_branch_2_final(ort2, prj2)

		# branch 3
        b3 = self.layer_branch_3_final_reinforce(ort3, prj3, b2)
        #b3 = self.layer_branch_3_final(ort3, prj3)

        return b1, b2, b3
    

#############################################################################################################################################
#############################################################################################################################################
#############################################################################################################################################

class HD_CAPSNET_NS_CF10(torch.nn.Module):

    def __init__(self, input_shape, no_coarse_classes = 2, no_medium_classes = 7, no_fine_classes = 10, dataset = None, bias = False):
        super().__init__()

        self.n_coarse = no_coarse_classes
        self.n_medium = no_medium_classes
        self.n_fine = no_fine_classes
        self.C, self.H, self.W = input_shape
        self.activation = torch.nn.ReLU()
        self.branch = 2048
        self.lin_in = 2048
        self.v = torch.tensor(0., device = "cuda:0")
        self.dataset = dataset
        self.bias = bias

        self.c2_reinforcer = torch.empty((128, self.n_medium), device = "cuda:0")
        self.c3_reinforcer = torch.empty((128, self.n_fine), device = "cuda:0")

        self.layer1 = nn.Conv2d(self.C, 64, 3, padding=1, bias=bias)
        self.layer2 = nn.BatchNorm2d(64)
        self.layer3 = nn.Conv2d(64, 64, 3, padding=1, bias=bias)
        self.layer4 = nn.BatchNorm2d(64)
        self.layer5 = nn.MaxPool2d(2, 2)

        self.layer6 = nn.Conv2d(64, 128, 3, padding=1, bias=bias)
        self.layer7 = nn.BatchNorm2d(128)
        self.layer8 = nn.Conv2d(128, 128, 3, padding=1, bias=bias)
        self.layer9 = nn.BatchNorm2d(128)
        self.layer10 = nn.MaxPool2d(2, 2)

        self.layer11 = nn.Conv2d(128, 256, 3, padding=1, bias=bias)
        self.layer12 = nn.BatchNorm2d(256)
        self.layer13 = nn.Conv2d(256, 256, 3, padding=1, bias=bias)
        self.layer14 = nn.BatchNorm2d(256)
        self.layer15 = nn.MaxPool2d(2, 2)

        self.layer16 = nn.Conv2d(256, 512, 3, padding=1, bias=True)
        self.layer17 = nn.BatchNorm2d(512)
        self.layer18 = nn.Conv2d(512, 512, 3, padding=1, bias=True)
        self.layer19 = nn.BatchNorm2d(512)
        self.layer20 = nn.MaxPool2d(2, 2)

        #self.layerb_mid = nn.Linear(self.lin_in, self.branch, bias=False)

        self.layer_b17 = nn.Linear(self.branch, self.n_coarse)
        self.layer_b27 = nn.Linear(self.branch, self.n_medium)
        self.layer_b37 = nn.Linear(self.branch, self.n_fine)

        self.I = torch.eye(self.branch, device = "cuda:0")
        self.I_1 = torch.eye(self.layer_b17.out_features, device="cuda:0")
        self.I_2 = torch.eye(self.layer_b17.out_features + self.layer_b27.out_features, device="cuda:0")

    def forward_branch(self, z):
        #z = self.layerb_mid(z)
        #z = self.activation(z)

        return z
    
    def forward_conv(self, z):
        return z

    def c2_reinforce(self, c1_logits):
        return self.dataset.c2_reinforce(c1_logits - torch.max(c1_logits), self.c2_reinforcer)
    
    def c3_reinforce(self, c2_logits):
        return self.dataset.c3_reinforce(c2_logits - torch.max(c2_logits), self.c3_reinforcer)

    def layer_branch_2_final_reinforce(self, ort, prj, b1):
        return self.layer_b27(ort + prj) + self.c2_reinforce(b1.clone().detach())
    
    def layer_branch_3_final_reinforce(self, ort, prj, b2):
        return self.layer_b37(ort + prj) + self.c3_reinforce(b2.clone().detach())

    

    def project(self, z): # https://math.stackexchange.com/questions/4021915/projection-orthogonal-to-two-vectors

        #start_time = time()
        W1 = self.layer_b17.weight.clone().detach()
        W2 = self.layer_b27.weight.clone().detach()
        ort2 = torch.empty_like(z)
        ort3 = torch.empty_like(z)

        zz = z.clone().detach()

        mask = torch.heaviside(zz, self.v)
        Rk = torch.einsum('ij, jh -> ijh', mask, self.I)
        W1k = W1.matmul(Rk)
        W2k_ = W2.matmul(Rk)
        W2k = torch.cat((W1k, W2k_), dim = 1)

        ort2 = self.compute_orthogonal(z, W1k, self.I_1)
        ort3 = self.compute_orthogonal(z, W2k, self.I_2)

        self.ort2 = ort2.clone().detach()
        self.ort3 = ort3.clone().detach()

        prj2 = zz - self.ort2
        prj3 = zz - self.ort3
        #print(f"project operation took: {time() - start_time} seconds")
        return ort2, ort3, prj2, prj3

    def compute_orthogonal(self, z, W, I_o = None, eps = 1e-8):
        WWT = torch.matmul(W, W.mT)

        P = solve_matrix_system((WWT + eps), I_o) # IN CASE ADD EPS
        P = torch.matmul(P, W)

        P = self.I - torch.matmul(W.mT, P) # Broadcasting

        return torch.matmul(z.unsqueeze(1), P).squeeze()

    def forward(self, x):

        batchsize = x.size(0)
        x = x.to(device="cuda:0")

        z = self.layer1(x)
        z = self.activation(z)
        z = self.layer2(z)
        z = self.layer3(z)
        z = self.activation(z)
        z = self.layer4(z)
        z = self.layer5(z)

        z = self.layer6(z)
        z = self.activation(z)
        z = self.layer7(z)
        z = self.layer8(z)
        z = self.activation(z)
        z = self.layer9(z)
        z = self.layer10(z)

        z = self.layer11(z)
        z = self.activation(z)
        z = self.layer12(z)
        z = self.layer13(z)
        z = self.activation(z)
        z = self.layer14(z)
        z = self.layer15(z)

        z = self.layer16(z)
        z = self.activation(z)
        z = self.layer17(z)
        z = self.layer18(z)
        z = self.activation(z)
        z = self.layer19(z)
        z = self.layer20(z)

        z = self.forward_conv(z)

        z = torch.flatten(z, start_dim = 1)

        z = self.forward_branch(z)

        ort2, ort3, prj2, prj3 = self.project(z)

		# branch 1
        b1 = self.layer_b17(z)
		
		# branch 2
        b2 = self.layer_branch_2_final_reinforce(ort2, prj2, b1)
        
		# branch 3
        b3 = self.layer_branch_3_final_reinforce(ort3, prj3, b2)


        return b1, b2, b3
    

class HD_CAPSNET_NS_CF10_HALF(HD_CAPSNET_NS_CF10):
    def __init__(self, input_shape, no_coarse_classes = 2, no_medium_classes = 7, no_fine_classes = 10, dataset = None, bias = False):
        super().__init__(input_shape, no_coarse_classes, no_medium_classes, no_fine_classes, dataset, bias)

        self.branch = 1024
        self.lin_in = 1024
        self.bias = bias

        self.layer1 = nn.Conv2d(self.C, 32, 3, padding=1, bias=bias)
        self.layer2 = nn.BatchNorm2d(32)
        self.layer3 = nn.Conv2d(32, 32, 3, padding=1, bias=bias)
        self.layer4 = nn.BatchNorm2d(32)
        self.layer5 = nn.MaxPool2d(2, 2)

        self.layer6 = nn.Conv2d(32, 64, 3, padding=1, bias=bias)
        self.layer7 = nn.BatchNorm2d(64)
        self.layer8 = nn.Conv2d(64, 64, 3, padding=1, bias=bias)
        self.layer9 = nn.BatchNorm2d(64)
        self.layer10 = nn.MaxPool2d(2, 2)

        self.layer11 = nn.Conv2d(64, 128, 3, padding=1, bias=bias)
        self.layer12 = nn.BatchNorm2d(128)
        self.layer13 = nn.Conv2d(128, 128, 3, padding=1, bias=bias)
        self.layer14 = nn.BatchNorm2d(128)
        self.layer15 = nn.MaxPool2d(2, 2)

        self.layer16 = nn.Conv2d(128, 256, 3, padding=1, bias=bias)
        self.layer17 = nn.BatchNorm2d(256)
        self.layer18 = nn.Conv2d(256, 256, 3, padding=1, bias=bias)
        self.layer19 = nn.BatchNorm2d(256)
        self.layer20 = nn.MaxPool2d(2, 2)

        self.layer_b17 = nn.Linear(self.branch, self.n_coarse)
        self.layer_b27 = nn.Linear(self.branch, self.n_medium)
        self.layer_b37 = nn.Linear(self.branch, self.n_fine)

        self.I = torch.eye(self.branch, device = "cuda:0")
        self.I_1 = torch.eye(self.layer_b17.out_features, device="cuda:0")
        self.I_2 = torch.eye(self.layer_b17.out_features + self.layer_b27.out_features, device="cuda:0")
    

class HD_CAPSNET_CF10(torch.nn.Module):

    def __init__(self, input_shape, no_coarse_classes = 2, no_medium_classes = 7, no_fine_classes = 10, PCap_n_dims = 8, SCap_f_dims = 8, SCap_m_dims = 16, SCap_c_dims = 32):
        super().__init__()

        self.n_coarse = no_coarse_classes
        self.n_medium = no_medium_classes
        self.n_fine = no_fine_classes
        self.Pcap_dim = PCap_n_dims
        self.Scap_c_dim = SCap_c_dims
        self.Scap_m_dim = SCap_m_dims
        self.Scap_f_dim = SCap_f_dims
        self.C, self.H, self.W = input_shape
        self.activation = torch.nn.ReLU()

        self.layer1 = nn.Conv2d(self.C, 64, 3, padding=1)
        self.layer2 = nn.BatchNorm2d(64)
        self.layer3 = nn.Conv2d(64, 64, 3, padding=1)
        self.layer4 = nn.BatchNorm2d(64)
        self.layer5 = nn.MaxPool2d(2, 2)

        self.layer6 = nn.Conv2d(64, 128, 3, padding=1)
        self.layer7 = nn.BatchNorm2d(128)
        self.layer8 = nn.Conv2d(128, 128, 3, padding=1)
        self.layer9 = nn.BatchNorm2d(128)
        self.layer10 = nn.MaxPool2d(2, 2)

        self.layer11 = nn.Conv2d(128, 256, 3, padding=1)
        self.layer12 = nn.BatchNorm2d(256)
        self.layer13 = nn.Conv2d(256, 256, 3, padding=1)
        self.layer14 = nn.BatchNorm2d(256)
        self.layer15 = nn.MaxPool2d(2, 2)

        self.layer16 = nn.Conv2d(256, 512, 3, padding=1)
        self.layer17 = nn.BatchNorm2d(512)
        self.layer18 = nn.Conv2d(512, 512, 3, padding=1)
        self.layer19 = nn.BatchNorm2d(512)
        self.layer20 = nn.MaxPool2d(2, 2)

        #self.sec_f = SecondaryCapsule(self.n_fine, self.Scap_f_dim, 2, 135, 16)
        self.sec_f = SecondaryCapsule(self.n_fine, self.Scap_f_dim, 2, 148, 16)
        #self.sec_m = SecondaryCapsule(self.n_medium, self.Scap_m_dim, 2, 66, 32)
        self.sec_m = SecondaryCapsule(self.n_medium, self.Scap_m_dim, 2, 72, 32)
        self.sec_c = SecondaryCapsule(self.n_coarse, self.Scap_c_dim, 2, 256, 8)

        self.predictor = LengthLayer()

    def forward(self, x):

        batchsize = x.size(0)
        x = x.to(device="cuda:0")

        z = self.layer1(x)
        if torch.isnan(z).any().item():
            print("AFTER LAYER1")
            print(torch.mean(x[1:]))
            sys.exit(12)
        z = self.activation(z)
        z = self.layer2(z)
        z = self.layer3(z)
        z = self.activation(z)
        z = self.layer4(z)
        z = self.layer5(z)

        z = self.layer6(z)
        z = self.activation(z)
        z = self.layer7(z)
        z = self.layer8(z)
        z = self.activation(z)
        z = self.layer9(z)
        z = self.layer10(z)

        z = self.layer11(z)
        z = self.activation(z)
        z = self.layer12(z)
        z = self.layer13(z)
        z = self.activation(z)
        z = self.layer14(z)
        z = self.layer15(z)

        z = self.layer16(z)
        z = self.activation(z)
        z = self.layer17(z)
        z = self.layer18(z)
        z = self.activation(z)
        z = self.layer19(z)
        z = self.layer20(z)


        z = z.view(batchsize, -1, self.Pcap_dim)
        p_caps_c = squash(z)
        sec_c = self.sec_c(p_caps_c)

        p_caps_m = p_caps_c.view(batchsize, -1, sec_c.shape[-1])
        skip_m = torch.cat((p_caps_m, sec_c), dim=1)
        sec_m = self.sec_m(skip_m)

        p_caps_f = p_caps_c.view(batchsize, -1, sec_m.shape[-1])
        skip_f = torch.cat((p_caps_f, sec_m), dim=1)
        sec_f = self.sec_f(skip_f)

        pred_c = self.predictor(sec_c)
        pred_m = self.predictor(sec_m)
        pred_f = self.predictor(sec_f)

        return pred_c, pred_m, pred_f
    
    

class HCNN3(nn.Module):
	
    def __init__(self, input_shape, no_coarse_classes = 2, no_medium_classes = 7, no_fine_classes = 10, dataset = None):
		
        super().__init__()

        self.n_coarse = no_coarse_classes
        self.n_medium = no_medium_classes
        self.n_fine = no_fine_classes
        self.C, self.H, self.W = input_shape
        self.activation = nn.ReLU()
        self.branch = 1024
        self.lin_in = 1024
        self.v = torch.tensor(0., device = "cuda:0")
        self.dataset = dataset

        self.c2_reinforcer = torch.empty((128, self.n_medium), device = "cuda:0")
        self.c3_reinforcer = torch.empty((128, self.n_fine), device = "cuda:0")

        self.layer1  = nn.Conv2d(3, 64, (3,3), padding = 'same', bias = False)
        self.layer2  = nn.BatchNorm2d(64)
        self.layer3  = nn.Conv2d(64, 64, (3,3), padding = 'same', bias = False)
        self.layer4  = nn.BatchNorm2d(64)
        self.layer5  = nn.MaxPool2d((2,2), stride = (2,2))

        self.layer6  = nn.Conv2d(64, 128, (3,3), padding = 'same', bias = False)
        self.layer7  = nn.BatchNorm2d(128)
        self.layer8  = nn.Conv2d(128, 128, (3,3), padding = 'same', bias = False)
        self.layer9  = nn.BatchNorm2d(128)
        self.layer10 = nn.MaxPool2d((2,2), stride = (2,2))

        self.layerb17 = nn.Linear(self.branch, self.n_coarse)

        self.layerb27 = nn.Linear(self.branch, self.n_medium)

        self.layerb37 = nn.Linear(self.branch, self.n_fine)
		
        self.layer_branch_2_final = self.layer_branch_2_final_reinforce
        self.layer_branch_3_final =	self.layer_branch_3_final_reinforce

        self.I = torch.eye(self.branch, device = "cuda:0")
        self.I_1 = torch.eye(self.layerb17.out_features, device="cuda:0")
        self.I_2 = torch.eye(self.layerb17.out_features + self.layerb27.out_features, device="cuda:0")

    def c2_reinforce(self, c1_logits):
        return self.dataset.c2_reinforce(c1_logits - torch.max(c1_logits), self.c2_reinforcer)
    
    def c3_reinforce(self, c2_logits):
        return self.dataset.c3_reinforce(c2_logits - torch.max(c2_logits), self.c3_reinforcer)
	
	
    def forward_conv(self, x):
        return x
        
        
    def forward_branch(self, x):
        return x        

    def layer_branch_2_final_reinforce(self, ort, prj, b1):
        return self.layerb27(ort + prj) + self.c2_reinforce(b1.clone().detach())
        
        
    def layer_branch_3_final_reinforce(self, ort, prj, b2):
        return self.layerb37(ort + prj) + self.c3_reinforce(b2.clone().detach())


    def project(self, z): # https://math.stackexchange.com/questions/4021915/projection-orthogonal-to-two-vectors

        #start_time = time()
        W1 = self.layerb17.weight.clone().detach()
        W2 = self.layerb27.weight.clone().detach()
        ort2 = torch.empty_like(z)
        ort3 = torch.empty_like(z)

        zz = z.clone().detach()

        mask = torch.heaviside(zz, self.v)
        Rk = torch.einsum('ij, jh -> ijh', mask, self.I)
        W1k = W1.matmul(Rk)
        W2k_ = W2.matmul(Rk)
        W2k = torch.cat((W1k, W2k_), dim = 1)

        ort2 = self.compute_orthogonal(z, W1k, self.I_1)
        ort3 = self.compute_orthogonal(z, W2k, self.I_2)

        self.ort2 = ort2.clone().detach()
        self.ort3 = ort3.clone().detach()

        prj2 = zz - self.ort2
        prj3 = zz - self.ort3
        #print(f"project operation took: {time() - start_time} seconds")
        return ort2, ort3, prj2, prj3

    def compute_orthogonal(self, z, W, I_o = None, eps = 1e-8):
        WWT = torch.matmul(W, W.mT)

        P = solve_matrix_system((WWT + eps), I_o) # IN CASE ADD EPS
        P = torch.matmul(P, W)

        P = self.I - torch.matmul(W.mT, P) # Broadcasting

        return torch.matmul(z.unsqueeze(1), P).squeeze()

        
    def forward(self, x):
        
        # block 1
        z = self.layer1(x)
        z = self.activation(z)
        z = self.layer2(z)
        z = self.layer3(z)
        z = self.activation(z)
        z = self.layer4(z)
        z = self.layer5(z)

        # block 2
        z = self.layer6(z)
        z = self.activation(z)
        z = self.layer7(z)
        z = self.layer8(z)
        z = self.activation(z)
        z = self.layer9(z)
        z = self.layer10(z)
        
        z = self.forward_conv(z)
        
        z = torch.flatten(z, start_dim = 1)
        
        z = self.forward_branch(z)

        # projections
        ort2, ort3, prj2, prj3 = self.project(z)

        # branch 1
        b1 = self.layerb17(z)
        
        # branch 2
        b2 = self.layer_branch_2_final(ort2, prj2, b1)

        # branch 3
        b3 = self.layer_branch_3_final(ort3, prj3, b2)

        return b1, b2, b3
    

class HCNN3_c2_b2(HCNN3):

    def __init__(self, input_shape, no_coarse_classes = 2, no_medium_classes = 7, no_fine_classes = 10, dataset = None):

        super().__init__(input_shape, no_coarse_classes, no_medium_classes, no_fine_classes, dataset)
		

        self.branch = 1024

        self.layer10_1 = nn.Conv2d(128, 256, (3,3), padding = 'same', bias = False)
        self.layer10_2 = nn.BatchNorm2d(256)
        self.layer10_3 = nn.Conv2d(256, 256, (3,3), padding = 'same', bias = False)
        self.layer10_4 = nn.BatchNorm2d(256)
        self.layer10_5 = nn.MaxPool2d((2,2), stride = (2,2))

        self.layerb11 = nn.Linear(4*4*256, self.branch, bias = False)
        self.layerb12 = nn.BatchNorm1d(self.branch)
        self.layerb13 = nn.Dropout(0.5)
        self.layerb14 = nn.Linear(self.branch, self.branch, bias = False)
        self.layerb15 = nn.BatchNorm1d(self.branch)
        self.layerb16 = nn.Dropout(0.5)

        self.layerb_mid = nn.Linear(self.branch, self.branch)


    def forward_conv(self, z):
        
        z = self.layer10_1(z)
        z = self.activation(z)
        z = self.layer10_2(z)
        z = self.layer10_3(z)
        z = self.activation(z)
        z = self.layer10_4(z)
        z = self.layer10_5(z)
        
        return z


    def forward_branch(self, z):
        
        z = self.layerb11(z)
        z = self.activation(z)
        z = self.layerb12(z)
        z = self.layerb13(z)
        z = self.layerb14(z)
        z = self.activation(z)
        z = self.layerb15(z)
        z = self.layerb16(z)
        z = self.layerb_mid(z)
        z = self.activation(z)
        
        return z
    
class HD_CNN_MT(torch.nn.Module):

    def __init__(self, input_shape, no_coarse_classes = 2, no_medium_classes = 10, no_fine_classes = 38, dataset = None):
        super().__init__()

        self.n_coarse = no_coarse_classes
        self.n_medium = no_medium_classes
        self.n_fine = no_fine_classes
        self.C, self.H, self.W = input_shape
        self.activation = torch.nn.ReLU()
        self.branch = 4096
        self.lin_in = 1024
        self.v = torch.tensor(0., device = "cuda:0")
        self.dataset = dataset
        self.drop = nn.Dropout(0.30)

        self.c2_reinforcer = torch.empty((64, self.n_medium), device = "cuda:0")
        self.c3_reinforcer = torch.empty((64, self.n_fine), device = "cuda:0")

        self.layer1 = nn.Conv2d(self.C, 64, 3, padding=1, bias=False)
        self.layer2 = nn.BatchNorm2d(64)
        self.layer3 = nn.Conv2d(64, 64, 3, padding=1, bias=False)
        self.layer4 = nn.BatchNorm2d(64)
        self.layer5 = nn.MaxPool2d(2, 2)

        self.layer6 = nn.Conv2d(64, 128, 3, padding=1, bias=False)
        self.layer7 = nn.BatchNorm2d(128)
        self.layer8 = nn.Conv2d(128, 128, 3, padding=1, bias=False)
        self.layer9 = nn.BatchNorm2d(128)
        self.layer10 = nn.MaxPool2d(2, 2)

        self.layer11 = nn.Conv2d(128, 256, 3, padding=1, bias=False)
        self.layer12 = nn.BatchNorm2d(256)
        self.layer13 = nn.Conv2d(256, 256, 3, padding=1, bias=False)
        self.layer14 = nn.BatchNorm2d(256)
        self.layer15 = nn.MaxPool2d(2, 2)

        self.layer16 = nn.Conv2d(256, 256, 3, padding=1, bias=False)
        self.layer17 = nn.BatchNorm2d(256)
        self.layer18 = nn.Conv2d(256, 256, 3, padding=1, bias=False)
        self.layer19 = nn.BatchNorm2d(256)
        self.layer20 = nn.MaxPool2d(2, 2)

        self.layerb_mid = nn.Linear(self.branch, self.lin_in)

        self.layer_b17 = nn.Linear(self.lin_in, self.n_coarse)
        self.layer_b27 = nn.Linear(self.lin_in, self.n_medium)
        self.layer_b37 = nn.Linear(self.lin_in, self.n_fine)

        self.I = torch.eye(self.lin_in, device = "cuda:0")
        self.I_1 = torch.eye(self.layer_b17.out_features, device="cuda:0")
        self.I_2 = torch.eye(self.layer_b17.out_features + self.layer_b27.out_features, device="cuda:0")

    def forward_branch(self, z):
        z = self.layerb_mid(z)
        z = self.activation(z)

        return z
    
    def forward_conv(self, z):
        z = self.drop(z)

        return z

    def c2_reinforce(self, c1_logits):
        return self.dataset.c2_reinforce(c1_logits - torch.max(c1_logits), self.c2_reinforcer)
    
    def c3_reinforce(self, c2_logits):
        return self.dataset.c3_reinforce(c2_logits - torch.max(c2_logits), self.c3_reinforcer)

    def layer_branch_2_final_reinforce(self, ort, prj, b1):
        return self.layer_b27(ort + prj) + self.c2_reinforce(b1.clone().detach())
    
    def layer_branch_3_final_reinforce(self, ort, prj, b2):
        return self.layer_b37(ort + prj) + self.c3_reinforce(b2.clone().detach())


    def project(self, z): # https://math.stackexchange.com/questions/4021915/projection-orthogonal-to-two-vectors

        #start_time = time()
        W1 = self.layer_b17.weight.clone().detach()
        W2 = self.layer_b27.weight.clone().detach()
        ort2 = torch.empty_like(z)
        ort3 = torch.empty_like(z)

        zz = z.clone().detach()

        mask = torch.heaviside(zz, self.v)
        Rk = torch.einsum('ij, jh -> ijh', mask, self.I)
        W1k = W1.matmul(Rk)
        W2k_ = W2.matmul(Rk)
        W2k = torch.cat((W1k, W2k_), dim = 1)

        ort2 = self.compute_orthogonal(z, W1k, self.I_1)
        ort3 = self.compute_orthogonal(z, W2k, self.I_2)

        self.ort2 = ort2.clone().detach()
        self.ort3 = ort3.clone().detach()

        prj2 = zz - self.ort2
        prj3 = zz - self.ort3
        #print(f"project operation took: {time() - start_time} seconds")
        return ort2, ort3, prj2, prj3

    def compute_orthogonal(self, z, W, I_o = None, eps = 1e-5):
        WWT = torch.matmul(W, W.mT)
        #reg = eps * torch.eye(WWT.shape[0], device = W.device, dtype=W.dtype)

        try:
            P = solve_matrix_system(WWT, I_o)
        except torch._C._LinAlgError:
            try:
                P = solve_matrix_system(WWT + eps, I_o)
            except torch._C._LinAlgError:
                P = torch.linalg.pinv(WWT) @ I_o
        
        P = torch.matmul(P, W)

        P = self.I - torch.matmul(W.mT, P) # Broadcasting

        return torch.matmul(z.unsqueeze(1), P).squeeze()

    def forward(self, x):

        batchsize = x.size(0)
        x = x.to(device="cuda:0")

        z = self.layer1(x)
        z = self.activation(z)
        z = self.layer2(z)
        z = self.layer3(z)
        z = self.activation(z)
        z = self.layer4(z)
        z = self.layer5(z)

        z = self.layer6(z)
        z = self.activation(z)
        z = self.layer7(z)
        z = self.layer8(z)
        z = self.activation(z)        
        z = self.layer9(z)
        z = self.layer10(z)

        z = self.layer11(z)
        z = self.activation(z)
        z = self.layer12(z)
        z = self.layer13(z)
        z = self.activation(z)
        z = self.layer14(z)
        z = self.layer15(z)

        z = self.layer16(z)
        z = self.activation(z)        
        z = self.layer17(z)
        z = self.layer18(z)
        z = self.activation(z)        
        z = self.layer19(z)
        z = self.layer20(z)

        z = self.forward_conv(z)

        z = torch.flatten(z, start_dim = 1)

        z = self.forward_branch(z)

        ort2, ort3, prj2, prj3 = self.project(z)

		# branch 1
        b1 = self.layer_b17(z)
		
		# branch 2
        b2 = self.layer_branch_2_final_reinforce(ort2, prj2, b1)
        #b2 = self.layer_branch_2_final(ort2, prj2)

		# branch 3
        b3 = self.layer_branch_3_final_reinforce(ort3, prj3, b2)
        #b3 = self.layer_branch_3_final(ort3, prj3)

        return b1, b2, b3