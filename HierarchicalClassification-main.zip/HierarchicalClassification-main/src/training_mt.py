from datasets import CIFAR100, get_Marine_dataset
from hdcapsnet_cf100 import HD_CAPSNET_NS_CF100, HD_CAPSNET_NS_CF100_HALF, EarlyStopper, HD_CAPSNET_NS_CF100_NORELU, HD_CAPSNET_CF100, HD_CAPSNET_NS_CF100_LASTHF, HD_CAPSNET_NS_CF100_DOUBLE, HD_CAPSNET_MT
from hdcapsnet import HD_CAPSNET_CF10, HD_CNN_MT
from torch.utils.data import DataLoader
from tqdm import tqdm
from metrics import hmeasurements
from torch.optim.lr_scheduler import LambdaLR

import torchvision.transforms as T
import torch, torch.nn as nn
import utils, config, numpy as np, random, os, statistics, matplotlib.pyplot as plt, sys


def compute_mean_std(loader):
# Accumulators
    mean = 0.0
    std = 0.0
    total_images = 0

    for images, _ in loader:
        batch_size = images.size(0)
        images = images.view(batch_size, images.size(1), -1)

        mean += images.mean(2).sum(0)
        std += images.std(2).sum(0)     
        total_images += batch_size

    mean /= total_images
    std /= total_images
    return mean, std

if __name__ == "__main__":

    h1_ = []
    h2_ = []
    h0_ = []
    c_ = []
    em_ = []
    co_ = []
    me_ = []
    fi_ = []

    seed = 2
    np.random.seed(seed)
    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    os.environ["PYTHONHASHSEED"] = str(seed)

    labels_path_tr = "MarineTree/train_labels_comb.csv"
    labels_path_te = "MarineTree/test_labels_comb.csv"
    images_dir = "MarineTree/marine_images"

    dataset_sp = get_Marine_dataset('level_depth_3', 'MarineTree/', batch_size=64)

    one_hot_cm = dataset_sp.Matrix_coarse_to_medium_OneHot.to("cuda:0")
    one_hot_mf = dataset_sp.Matrix_medium_to_fine_OneHot.to("cuda:0")

    nc = {
        "coarse" : dataset_sp.num_classes_l0,
        "medium" : dataset_sp.num_classes_l1,
        "fine"   : dataset_sp.num_classes_l2
    }
    train_epochs = 21

    init_lw = utils.initial_lw(nc)
    lw = utils.initial_lw(nc)

    #model = HD_CAPSNET_MT((3,64,64), nc["coarse"], nc["medium"], nc["fine"]).to("cuda:0")
    model = HD_CNN_MT((3,64,64), dataset_sp.num_classes_l0, dataset_sp.num_classes_l1, dataset_sp.num_classes_l2, dataset_sp).to("cuda:0")
    pytorch_total_params = sum(p.numel() for p in model.parameters())
    print(f"NS total: {pytorch_total_params}")

    lr = 0.00005
    #lr = 0.001
    print(f"lr: {lr}, scheduler: 9, dropout: 0.30")
    optimizer = torch.optim.Adam(model.parameters(), lr)
    
    total_loss = [[],[],[]]
    val_total_loss = [[],[],[]]
    val_total_acc = [[],[],[]]
    train_total_acc = [[],[],[]]
    completed_epochs = 0
    lr_scheduler = LambdaLR(optimizer, lr_lambda=lambda epoch: utils.scheduler(epoch))
    early_stopping = utils.LexicographicEarlyStopping(patience=10, tolerances=[0.25, 0.5, 0.0])
    bce_loss = torch.nn.BCEWithLogitsLoss(reduction="mean")
    for epoch in tqdm(range(train_epochs)):
        model.train()
        labels = 0
        epoch_loss = [[],[],[]]
        coarse_pos, medium_pos, fine_pos = 0,0,0
        for img, yc, ym, yf in dataset_sp.train_dataset:

            #yc, ym, yf = lab
            img = img.to(device="cuda:0")
            yc, ym, yf = yc.to(device="cuda:0"), ym.to(device="cuda:0"), yf.to(device="cuda:0")

            img, yc, ym, yf = utils.mixup_data(img, yc, ym, yf)

            optimizer.zero_grad()
            coarse_pred, medium_pred, fine_pred = model(img)

            #loss_c, loss_m, loss_f = utils.CustomLoss2(yc, ym, yf, coarse_pred, medium_pred, fine_pred, lw["coarse"], lw["medium"], lw["fine"], nc["medium"], nc["fine"], dataset_sp.Matrix_coarse_to_medium_OneHot, dataset_sp.Matrix_medium_to_fine_OneHot)
            
            loss_c = utils.margin_loss(yc, coarse_pred)
            loss_m = utils.margin_loss(ym, medium_pred)
            loss_f = utils.margin_loss(yf, fine_pred)

            with torch.no_grad():
                loss_cm = 0.0
                for i, elem in enumerate(medium_pred):
                    loss_cm += bce_loss(elem, one_hot_cm[torch.argmax(coarse_pred[i]).item()]).to("cuda:0")
                loss_mf = 0.0
                for i, elem in enumerate(fine_pred):
                    loss_mf += bce_loss(elem, one_hot_mf[torch.argmax(medium_pred[i]).item()]).to("cuda:0")

            loss_cm *= 0.0004
            loss_mf *= 0.0002

            loss_m += loss_cm
            loss_f += loss_mf

            loss_c.backward(retain_graph = True)
            loss_m.backward(retain_graph = True)
            loss_f.backward()

            epoch_loss[0].append(loss_c.item())
            epoch_loss[1].append(loss_m.item())
            epoch_loss[2].append(loss_f.item())

            #loss = loss_c + loss_m + loss_f
            #loss.backward()

            c_pred, m_pred, f_pred = torch.argmax(coarse_pred, 1).to(dtype=torch.float), torch.argmax(medium_pred, 1).to(dtype=torch.float), torch.argmax(fine_pred, 1).to(dtype=torch.float)

            c_true, m_true, f_true = torch.argmax(yc, 1).to(dtype=torch.float), torch.argmax(ym, 1).to(dtype=torch.float), torch.argmax(yf, 1).to(dtype=torch.float)

            #labels += len(c_true)

            optimizer.step()

        total_loss[0].append(statistics.mean(epoch_loss[0]))
        total_loss[1].append(statistics.mean(epoch_loss[1]))
        total_loss[2].append(statistics.mean(epoch_loss[2]))

        model.eval()
        for img, yc, ym, yf in dataset_sp.val_dataset:

            coarse_pred, medium_pred, fine_pred = model(img)

            c_pred, m_pred, f_pred = torch.argmax(coarse_pred, 1).to(dtype=torch.float), torch.argmax(medium_pred, 1).to(dtype=torch.float), torch.argmax(fine_pred, 1).to(dtype=torch.float)

            c_true, m_true, f_true = torch.argmax(yc, 1).to(dtype=torch.float), torch.argmax(ym, 1).to(dtype=torch.float), torch.argmax(yf, 1).to(dtype=torch.float)

            labels += len(c_true)

            for j, elem in enumerate(c_true):
                if elem == c_pred[j]:
                    coarse_pos += 1
            for j, elem in enumerate(m_true):
                if elem == m_pred[j]:
                    medium_pos += 1
            for j, elem in enumerate(f_true):
                if elem == f_pred[j]:
                    fine_pos += 1

        print(f"Epoch {epoch}: C: {100*coarse_pos/labels}, M: {100*medium_pos/labels}, F: {100*fine_pos/labels}")
        val_metrics = [100*coarse_pos/labels, 100*medium_pos/labels, 100*fine_pos/labels]
        early_stopping(val_metrics, model)

        val_total_acc[0].append(val_metrics[0])
        val_total_acc[1].append(val_metrics[1])
        val_total_acc[2].append(val_metrics[2])
        completed_epochs += 1

        #if early_stopping.early_stop:
        #    print("Early stopping triggered.")
        #    break

        new_LW = utils.lw_modifier(init_lw, [coarse_pos/labels, medium_pos/labels, fine_pos/labels])

        lw["coarse"] = new_LW[0]
        lw["medium"] = new_LW[1]
        lw["fine"] = new_LW[2]
        lr_scheduler.step()

    #early_stopping.load_best_weights(model)
    #"""
    x_ax = [i for i in range(completed_epochs)]
    plt.plot(x_ax, total_loss[0], label="loss coarse")
    plt.plot(x_ax, total_loss[1], '-.', label="loss medium")
    plt.plot(x_ax, total_loss[2], '-', label="loss fine")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.legend()
    plt.title('HD-CNN-NS Train Losses')
    plt.savefig(f"T_LOSS.png")
    plt.close()
    

    x_ax = [i for i in range(completed_epochs)]
    plt.plot(x_ax, val_total_acc[0], label="acc coarse")
    plt.plot(x_ax, val_total_acc[1], '-.', label="acc medium")
    plt.plot(x_ax, val_total_acc[2], '-', label="acc fine")
    plt.xlabel("Epoch")
    plt.ylabel("Accuracy")
    plt.legend()
    plt.title('HD-CNN-NS Validation Accuracies')
    plt.savefig(f"VAL_ACC.png")
    plt.close()

    coarse_pos, medium_pos, fine_pos = 0,0,0
    true_label_c, true_label_m, true_label_f = [], [], []
    pred_label_c, pred_label_m, pred_label_f = [], [], []
    #"""
    model.eval()
    with torch.no_grad():
        for img, yc, ym, yf in dataset_sp.test_dataset:

            img = img.to(device="cuda:0")
            yc, ym, yf = yc.to(device="cuda:0"), ym.to(device="cuda:0"), yf.to(device="cuda:0")

            coarse_pred, medium_pred, fine_pred = model(img)

            c_pred, m_pred, f_pred = torch.argmax(coarse_pred, 1).to(dtype=torch.float), torch.argmax(medium_pred, 1).to(dtype=torch.float), torch.argmax(fine_pred, 1).to(dtype=torch.float)

            c_true, m_true, f_true = torch.argmax(yc, 1).to(dtype=torch.float), torch.argmax(ym, 1).to(dtype=torch.float), torch.argmax(yf, 1).to(dtype=torch.float)

            true_label_c.append(yc.detach().cpu())
            true_label_m.append(ym.detach().cpu())
            true_label_f.append(yf.detach().cpu())

            pred_label_c.append(coarse_pred.detach().cpu())
            pred_label_m.append(medium_pred.detach().cpu())
            pred_label_f.append(fine_pred.detach().cpu())

            for j, elem in enumerate(c_true):
                if elem == c_pred[j]:
                    coarse_pos += 1
            for j, elem in enumerate(m_true):
                if elem == m_pred[j]:
                    medium_pos += 1
            for j, elem in enumerate(f_true):
                if elem == f_pred[j]:
                    fine_pos += 1

    true_label_c = torch.cat(true_label_c)
    true_label_m = torch.cat(true_label_m)
    true_label_f = torch.cat(true_label_f)
    pred_label_c = torch.cat(pred_label_c)
    pred_label_m = torch.cat(pred_label_m)
    pred_label_f = torch.cat(pred_label_f)

    true_label = [true_label_c, true_label_m, true_label_f]
    pred_label = [pred_label_c, pred_label_m, pred_label_f]

    h_measurements,consistency,exact_match = hmeasurements(true_label,
                                        pred_label,
                                        dataset_sp.tree)
    print('\nHierarchical Precision =',h_measurements[0],
        '\nHierarchical Recall =', h_measurements[1],
        '\nHierarchical F1-Score =',h_measurements[2],
        '\n Consistency = ', consistency,
        '\n Exact Match = ', exact_match,
        )    
    print(100*coarse_pos/len(true_label_c))
    print(100*medium_pos/len(true_label_c))
    print(100*fine_pos/len(true_label_c))
        
    """
    h0_.append(h_measurements[0])
    h1_.append(h_measurements[1])
    h2_.append(h_measurements[2])
    c_.append(consistency)
    em_.append(exact_match)
    co_.append(100*coarse_pos/len(true_label_c))
    me_.append(100*medium_pos/len(true_label_c))
    fi_.append(100*fine_pos/len(true_label_c))"
    

    print(f"H_P mean: {statistics.mean(h0_)}, deviation: {statistics.stdev(h0_)}")
    print(f"H_R mean: {statistics.mean(h1_)}, deviation: {statistics.stdev(h1_)}")
    print(f"H_F1 mean: {statistics.mean(h2_)}, deviation: {statistics.stdev(h2_)}")
    print(f"C mean: {statistics.mean(c_)}, deviation: {statistics.stdev(c_)}")
    print(f"EM mean: {statistics.mean(em_)}, deviation: {statistics.stdev(em_)}")
    print(f"CO mean: {statistics.mean(co_)}, deviation: {statistics.stdev(co_)}")
    print(f"ME mean: {statistics.mean(me_)}, deviation: {statistics.stdev(me_)}")
    print(f"FI mean: {statistics.mean(fi_)}, deviation: {statistics.stdev(fi_)}")
    """