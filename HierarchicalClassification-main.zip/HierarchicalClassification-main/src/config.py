import torchvision.transforms as T
import torch.nn as nn, torch
from hdcapsnet import MarginLoss
from datasets import F_MNIST, CIFAR10, CIFAR100
import utils

F_MNIST_MEAN = [0.2860]
F_MNIST_STD = [0.3205]
CIFAR10_MEAN = (0.4914, 0.4822, 0.4465)
CIFAR10_STD = (0.2023, 0.1994, 0.2010)
CIFAR100_MEAN = (0.5071, 0.4867, 0.4408)
CIFAR100_STD = (0.2675, 0.2565, 0.2761)

F_MNIST_TRANSFORM = T.Compose([
    T.RandomAffine(
        degrees=0,
        translate=(0.1, 0.1)   # horizontal/vertical shift up to 10%
    ),
    T.ToTensor(),
    T.Normalize(mean=F_MNIST_MEAN, std=F_MNIST_STD),
])

CIFAR10_TRANSFORM = T.Compose([
    T.RandomAffine(
        degrees=0,
        translate=(0.1, 0.1)   # horizontal/vertical shift up to 10%
    ),
    #T.RandomCrop(32, padding=4), 
    #T.RandomHorizontalFlip(),
    T.ToTensor(),
    T.Normalize(mean=CIFAR10_MEAN, std=CIFAR10_STD),
])

CIFAR100_TRANSFORM = T.Compose([
    T.RandomAffine(
        degrees=0,
        translate=(0.1, 0.1)   # horizontal/vertical shift up to 10%
    ),
    #T.RandomCrop(32, padding=4), 
    #T.RandomHorizontalFlip(),
    T.ToTensor(),
    T.Normalize(mean=CIFAR100_MEAN, std=CIFAR100_STD),
])

F_MNIST_TRAIN_PARAMS = {"n_epochs" : 100,
                "batch_size": 64,
                "lr": 0.001, # Initial learning rate
                "lr_decay": 0.95, # Learning rate decay
                "decay_exe": 9, #learning rate decay execution epoch after
               } 

CIFAR10_TRAIN_PARAMS = {"n_epochs" : 100,
                "batch_size": 64,
                "lr": 0.0012739586445288998, # Initial learning rate
                #"lr": 0.001,
                "lr_decay": 0.90, # Learning rate decay
                "decay_exe": 9, #learning rate decay execution epoch after
               }

CIFAR100_TRAIN_PARAMS = {"n_epochs" : 100,
                "batch_size": 64,
                "lr": 0.00040903491440640895, # Initial learning rate
                #"lr": 0.0001,
                "lr_decay": 0.90, # Learning rate decay
                "decay_exe": 9, #learning rate decay execution epoch after
               } 

F_MNIST_INITIAL_LW = utils.initial_lw(utils.num_classes(F_MNIST()))
CIFAR10_INITIAL_LW = utils.initial_lw(utils.num_classes(CIFAR10()))
CIFAR100_INITIAL_LW = utils.initial_lw(utils.num_classes(CIFAR100()))

F_MNIST_MODEL_PARAMS = {"P_Cap_Dim" : 8, # Primary Capsule Dimentions
                "S_Cap_Dim" : 16, # Secondary Capsule Dimention
                "Reconstruction_LW" : 0.0000, # Decoder loss weight
                "class_loss" : MarginLoss(), ## Class prediction loss
                "reconstruction_loss" : nn.MSELoss()
               }

CIFAR10_MODEL_PARAMS = {"P_Cap_Dim" : 8, # Primary Capsule Dimentions
                "S_Cap_f_Dim" : 8,
                "S_Cap_m_Dim" : 16, # Secondary Capsule Dimention
                "S_Cap_c_Dim" : 32,
                "Reconstruction_LW" : 0.0000, # Decoder loss weight
                "class_loss" : MarginLoss(), ## Class prediction loss
                "reconstruction_loss" : nn.MSELoss()
               }

F_MNIST_LOSS_W = {
    "coarse": nn.Parameter(torch.tensor(F_MNIST_INITIAL_LW['coarse'], dtype=torch.float32)),
    "medium": nn.Parameter(torch.tensor(F_MNIST_INITIAL_LW['medium'], dtype=torch.float32)),
    "fine":   nn.Parameter(torch.tensor(F_MNIST_INITIAL_LW['fine'],   dtype=torch.float32)),
    "decoder": 0.0
}

CIFAR10_LOSS_W = {
    "coarse": nn.Parameter(torch.tensor(CIFAR10_INITIAL_LW['coarse'], dtype=torch.float32)),
    "medium": nn.Parameter(torch.tensor(CIFAR10_INITIAL_LW['medium'], dtype=torch.float32)),
    "fine":   nn.Parameter(torch.tensor(CIFAR10_INITIAL_LW['fine'],   dtype=torch.float32)),
    "decoder": 0.0
}

CIFAR100_LOSS_W = {
    "coarse": nn.Parameter(torch.tensor(CIFAR100_INITIAL_LW['coarse'], dtype=torch.float32)),
    "medium": nn.Parameter(torch.tensor(CIFAR100_INITIAL_LW['medium'], dtype=torch.float32)),
    "fine":   nn.Parameter(torch.tensor(CIFAR100_INITIAL_LW['fine'],   dtype=torch.float32)),
    "decoder": 0.0   
}