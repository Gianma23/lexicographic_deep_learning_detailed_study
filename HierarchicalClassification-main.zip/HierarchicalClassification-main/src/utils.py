import torch, numpy as np, statistics
from torch.utils.data import Dataset
from torch.optim.lr_scheduler import LambdaLR
from torchsummary import summary
import torchvision.transforms as T
from PIL import Image
from hdcapsnet import HD_CAPSNET, HD_CAPSNET_NS, HD_CAPSNET_CF10, HD_CAPSNET_NS_CF10, HCNN3_c2_b2, HD_CAPSNET_NS_CF10_HALF, SecondaryCapsule
from hdcapsnet_cf100 import HD_CAPSNET_NS_CF100, HD_CAPSNET_NS_CF100_HALF, HD_CAPSNET_NS_CF100_NORELU, HD_CAPSNET_CF100, HD_CAPSNET_NS_CF100_LASTHF
from collections import defaultdict

class ThreeLevelDataset_FMNIST(Dataset):
    def __init__(self, images, y_coarse, y_medium, y_fine, transform=None):
        """
        images: numpy array or list of PIL images
        y_coarse/medium/fine: arrays or lists of labels
        """
        assert len(images) == len(y_coarse) == len(y_medium) == len(y_fine)
        self.images = images
        self.y_coarse = y_coarse
        self.y_medium = y_medium
        self.y_fine   = y_fine
        self.transform = transform

    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):
        img = self.images[idx]

        if not isinstance(img, Image.Image):
            img = T.functional.to_pil_image(img)
        
        if self.transform:
            img = self.transform(img)
        
        return img, \
               torch.tensor(self.y_coarse[idx], dtype=torch.float32), \
               torch.tensor(self.y_medium[idx], dtype=torch.float32), \
               torch.tensor(self.y_fine[idx],   dtype=torch.float32)
    
    def c2_reinforce(self, c1_logits, c2_reinforcer):
        num_rows = c1_logits.size(0)

        c2_reinforcer[:num_rows, 0] = c2_reinforcer[:num_rows, 1] = c2_reinforcer[:num_rows, 2] = c2_reinforcer[:num_rows, 3] = c1_logits[:,0]
        c2_reinforcer[:num_rows, 4] = c2_reinforcer[:num_rows, 5] = c1_logits[:,1]

        return c2_reinforcer[:num_rows,:]

    def c3_reinforce(self, c2_logits, c3_reinforcer):
        num_rows = c2_logits.size(0)

        c3_reinforcer[:num_rows, 0] = c3_reinforcer[:num_rows, 2] = c3_reinforcer[:num_rows, 6] = c2_logits[:,0]
        c3_reinforcer[:num_rows, 1] = c2_logits[:,1]
        c3_reinforcer[:num_rows, 3] = c2_logits[:,2]
        c3_reinforcer[:num_rows, 4] = c2_logits[:,3]
        c3_reinforcer[:num_rows, 8] = c2_logits[:,4]
        c3_reinforcer[:num_rows, 5] = c3_reinforcer[:num_rows, 7] = c3_reinforcer[:num_rows, 9] = c2_logits[:,5]

        return c3_reinforcer[:num_rows,:]
    

class ThreeLevelDataset_CIFAR10(Dataset):
    def __init__(self, images, y_coarse, y_medium, y_fine, transform=None):
        """
        images: numpy array or list of PIL images
        y_coarse/medium/fine: arrays or lists of labels
        """
        assert len(images) == len(y_coarse) == len(y_medium) == len(y_fine)
        self.images = images
        self.y_coarse = y_coarse
        self.y_medium = y_medium
        self.y_fine   = y_fine
        self.transform = transform

    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):
        img = self.images[idx]

        if not isinstance(img, Image.Image):
            img = T.functional.to_pil_image(img)
        
        if self.transform:
            img = self.transform(img)
        
        return img, \
               torch.tensor(self.y_coarse[idx], dtype=torch.float32), \
               torch.tensor(self.y_medium[idx], dtype=torch.float32), \
               torch.tensor(self.y_fine[idx],   dtype=torch.float32)
    
    def c2_reinforce(self, c1_logits, c2_reinforcer):
        num_rows = c1_logits.size(0)
        c2_reinforcer[:num_rows, 0] = c2_reinforcer[:num_rows, 1] = c2_reinforcer[:num_rows, 2] = c1_logits[:,0]
        c2_reinforcer[:num_rows, 3] = c2_reinforcer[:num_rows, 4] = c2_reinforcer[:num_rows, 5] = c2_reinforcer[:num_rows, 6] = c1_logits[:,1]

        return c2_reinforcer[:num_rows,:]
    
    def c3_reinforce(self, c2_logits, c3_reinforcer):
        num_rows = c2_logits.size(0)
        c3_reinforcer[:num_rows, 0] = c2_logits[:,0]
        c3_reinforcer[:num_rows, 8] = c2_logits[:,1]
        c3_reinforcer[:num_rows, 1] = c3_reinforcer[:num_rows, 9] = c2_logits[:,2]
        c3_reinforcer[:num_rows, 2] = c2_logits[:,3]
        c3_reinforcer[:num_rows, 6] = c2_logits[:,4]
        c3_reinforcer[:num_rows, 3] = c3_reinforcer[:num_rows, 5] = c2_logits[:,5]
        c3_reinforcer[:num_rows, 4] = c3_reinforcer[:num_rows, 7] = c2_logits[:,6]

        return c3_reinforcer[:num_rows,:]
    

class ThreeLevelDataset_CIFAR100(Dataset):
    def __init__(self, images, y_coarse, y_medium, y_fine, transform=None):
        """
        images: numpy array or list of PIL images
        y_coarse/medium/fine: arrays or lists of labels
        """
        assert len(images) == len(y_coarse) == len(y_medium) == len(y_fine)
        self.images = images
        self.y_coarse = y_coarse
        self.y_medium = y_medium
        self.y_fine   = y_fine
        self.transform = transform

    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):
        img = self.images[idx]

        if not isinstance(img, Image.Image):
            img = T.functional.to_pil_image(img)
        
        if self.transform:
            img = self.transform(img)
        
        return img, \
               torch.tensor(self.y_coarse[idx], dtype=torch.float32), \
               torch.tensor(self.y_medium[idx], dtype=torch.float32), \
               torch.tensor(self.y_fine[idx],   dtype=torch.float32)
    
    
    def c2_reinforce(self, c1_logits, c2_reinforcer):

        coarse2_coarse1 = {
        0:0, 1:0, 2:1, 3:2,
        4:1, 5:2, 6:2, 7:3,
        8:4, 9:5, 10:5, 11:4,
        12:4, 13:3, 14:6, 15:4,
        16:4, 17:1, 18:7, 19:7
        }

        num_rows = c1_logits.size(0)
        for coarse2_idx, coarse1_idx in coarse2_coarse1.items():
            c2_reinforcer[:num_rows, coarse2_idx] = c1_logits[:, coarse1_idx]
        return c2_reinforcer[:num_rows, :]
    
    def c3_reinforce(self, c2_logits, c3_reinforcer):

        fine_coarse2 = {
        0:4,1:1,2:14,3:8,4:0,5:6,6:7,7:7,8:18,9:3,
        10:3,11:14,12:9,13:18,14:7,15:11,16:3,17:9,18:7,19:11,
        20:6,21:11,22:5,23:10,24:7,25:6,26:13,27:15,28:3,29:15,
        30:0,31:11,32:1,33:10,34:12,35:14,36:16,37:9,38:11,39:5,
        40:5,41:19,42:8,43:8,44:15,45:13,46:14,47:17,48:18,49:10,
        50:16,51:4,52:17,53:4,54:2,55:0,56:17,57:4,58:18,59:17,
        60:10,61:3,62:2,63:12,64:12,65:16,66:12,67:1,68:9,69:19,
        70:2,71:10,72:0,73:1,74:16,75:12,76:9,77:13,78:15,79:13,
        80:16,81:19,82:2,83:4,84:6,85:19,86:5,87:5,88:8,89:19,
        90:18,91:1,92:2,93:15,94:6,95:0,96:17,97:8,98:14,99:13
        }

        num_rows = c2_logits.size(0)
        for fine_idx, coarse2_idx in fine_coarse2.items():
            c3_reinforcer[:num_rows, fine_idx] = c2_logits[:, coarse2_idx]
        return c3_reinforcer[:num_rows, :]
    

def num_classes(dataset):

    fine_class = len(np.unique(np.argmax(dataset['y_train_fine'], axis=1)))
    medium_class = len(np.unique(np.argmax(dataset['y_train_medium'], axis=1)))
    coarse_class = len(np.unique(np.argmax(dataset['y_train_coarse'], axis=1)))

    return {
        "coarse": coarse_class,
        "medium": medium_class,
        "fine": fine_class
    }    

def initial_lw(class_labels: dict):
    """
    Give dictionary input for hierarchical levels.
    Where the values for the input keys needs to be total number of classes in the levels.
    Example for 3 levels hierarchy with 2, 6, 10 class will be in following format:
    class_labels = {"coarse": coarse_class, "medium": medium_class,"fine": fine_class}
    :c:The Function will return initial loss weight values in a dictionary, based on number of classes in levels
    """

    q = {}
    for k, v in class_labels.items():
        q[k] = (1 - (v / sum(class_labels.values())))

    c = {}
    for k, v in class_labels.items():
        c[k] = (q[k] / sum(q.values()))
        
    return c


def lw_modifier(lossweights: dict, predictions: list):
    ACC_C = predictions[0]
    ACC_M = predictions[1]
    ACC_F = predictions[2]

    tau1 = (1.0-ACC_C) * lossweights["coarse"]
    tau2 = (1.0-ACC_M) * lossweights["medium"]
    tau3 = (1.0-ACC_F) * lossweights["fine"]

    L1 = float((1-0) * (tau1 / (tau1 + tau2 + tau3)))
    L2 = float((1-0) * (tau2 / (tau1 + tau2 + tau3)))
    L3 = float((1-0) * (tau3 / (tau1 + tau2 + tau3)))

    return [L1, L2, L3]

def scheduler(epoch):
    learning_rate_init = 1
    
    if epoch > 9:
        learning_rate_init = 0.95 ** (epoch-9)
        
    return learning_rate_init


def get_pytorch_setup(model, num_classes, model_params, train_params, loss_weights, dataset = None, bias = False):

    if issubclass(model, (HD_CAPSNET, HD_CAPSNET_NS)):
        if issubclass(model, HD_CAPSNET):
            model = model(
                (1 , 28 , 28), num_classes["coarse"], num_classes["medium"], num_classes["fine"]
            )
        else:
            model = model(
                (1 , 28 , 28), num_classes["coarse"], num_classes["medium"], num_classes["fine"], dataset = dataset, bias = bias
            )

    elif issubclass(model, (HD_CAPSNET_CF10, HD_CAPSNET_NS_CF10, HD_CAPSNET_NS_CF10_HALF)):           
        if issubclass(model, HD_CAPSNET_CF10):

            model = model(
                (3 , 32 , 32), num_classes["coarse"], num_classes["medium"], num_classes["fine"]
            )
        else:
            model = model(
                (3 , 32 , 32), num_classes["coarse"], num_classes["medium"], num_classes["fine"], dataset = dataset, bias = bias
            )

    elif issubclass(model, (HD_CAPSNET_CF100)):
            model = model(
                (3 , 32 , 32), num_classes["coarse"], num_classes["medium"], num_classes["fine"]
            )

    elif issubclass(model, (HD_CAPSNET_NS_CF100_NORELU)):
        model = model(
            (3 , 32 , 32), num_classes["coarse"], num_classes["medium"], num_classes["fine"], dataset = dataset, bias = bias
        )    

    elif issubclass(model, (HD_CAPSNET_NS_CF100_HALF, HD_CAPSNET_NS_CF100)):
        model = model(
            (3 , 32 , 32), num_classes["coarse"], num_classes["medium"], num_classes["fine"], dataset = dataset, bias = bias
        )        

    elif issubclass(model, HCNN3_c2_b2):
        model = model(
            (3 , 32 , 32), num_classes["coarse"], num_classes["medium"], num_classes["fine"], dataset = dataset
        )         

    pytorch_total_params = sum(p.numel() for p in model.parameters())
    print(f"NS total: {pytorch_total_params}")

    optimizer = torch.optim.Adam(model.parameters(), train_params["lr"])

    class_loss_fn      = model_params["class_loss"]
    reconstruction_fn  = model_params["reconstruction_loss"]

    lr_scheduler = LambdaLR(optimizer, lr_lambda=lambda epoch: scheduler(epoch))

    def accuracy(pred, target):
        return (pred.argmax(dim=1) == target).float().mean()

    return {
        "model":           model,
        "optimizer":       optimizer,
        "class_loss_fn":   class_loss_fn,
        "reconstruction_fn": reconstruction_fn,
        "loss_weights":    loss_weights,
        "accuracy_fn":     accuracy,
        "lr_scheduler":    lr_scheduler
    }


def get_pytorch_setup_optuna(model, num_classes, model_params, train_params, loss_weights, dataset = None, bias = False, lr = None):

    if issubclass(model, (HD_CAPSNET, HD_CAPSNET_NS)):
        if issubclass(model, HD_CAPSNET):
            model = model(
                (1 , 28 , 28), num_classes["coarse"], num_classes["medium"], num_classes["fine"]
            )
        else:
            model = model(
                (1 , 28 , 28), num_classes["coarse"], num_classes["medium"], num_classes["fine"], dataset = dataset, bias = bias
            )

    elif issubclass(model, (HD_CAPSNET_CF10, HD_CAPSNET_NS_CF10, HD_CAPSNET_NS_CF10_HALF)):           
        if issubclass(model, HD_CAPSNET_CF10):
            model = model(
                (3 , 32 , 32), num_classes["coarse"], num_classes["medium"], num_classes["fine"]
            )
        else:
            model = model(
                (3 , 32 , 32), num_classes["coarse"], num_classes["medium"], num_classes["fine"], dataset = dataset, bias = bias
            )

    elif issubclass(model, (HD_CAPSNET_NS_CF100_NORELU)):
        model = model(
            (3 , 32 , 32), num_classes["coarse"], num_classes["medium"], num_classes["fine"], dataset = dataset, bias = bias
        )     

    elif issubclass(model, (HD_CAPSNET_NS_CF100_LASTHF, HD_CAPSNET_NS_CF100_HALF, HD_CAPSNET_NS_CF100)):
        model = model(
            (3 , 32 , 32), num_classes["coarse"], num_classes["medium"], num_classes["fine"], dataset = dataset, bias = bias
        )            

    elif issubclass(model, HCNN3_c2_b2):
        model = model(
            (3 , 32 , 32), num_classes["coarse"], num_classes["medium"], num_classes["fine"], dataset = dataset
        )         

    pytorch_total_params = sum(p.numel() for p in model.parameters())
    print(f"NS total: {pytorch_total_params}")

    optimizer = torch.optim.Adam(model.parameters(), lr)

    class_loss_fn      = model_params["class_loss"]
    reconstruction_fn  = model_params["reconstruction_loss"]

    lr_scheduler = LambdaLR(optimizer, lr_lambda=lambda epoch: scheduler(epoch))

    def accuracy(pred, target):
        return (pred.argmax(dim=1) == target).float().mean()

    return {
        "model":           model,
        "optimizer":       optimizer,
        "class_loss_fn":   class_loss_fn,
        "reconstruction_fn": reconstruction_fn,
        "loss_weights":    loss_weights,
        "accuracy_fn":     accuracy,
        "lr_scheduler":    lr_scheduler
    }


def matrix_generator(num_classes, dataset):

    coarse_to_medium_array = np.zeros(shape=[num_classes["coarse"],num_classes["medium"]], dtype=np.int32)
    medium_to_fine_array = np.zeros(shape=[num_classes["medium"],num_classes["fine"]], dtype=np.int32)

    c_id = np.argmax(dataset['y_train_coarse'],1)

    m_id = np.argmax(dataset['y_train_medium'],1)

    f_id = np.argmax(dataset['y_train_fine'],1)

    for x in range(len(dataset['y_test_medium'])):
        coarse_to_medium_array[c_id[x]][m_id[x]] = 1
        
    for x in range(len(dataset['y_test_fine'])):
        medium_to_fine_array[m_id[x]][f_id[x]] = 1

    Matrix_coarse_to_medium_OneHot = torch.tensor(coarse_to_medium_array, dtype=torch.float32)
    Matrix_medium_to_fine_OneHot = torch.tensor(medium_to_fine_array, dtype=torch.float32)

    return Matrix_coarse_to_medium_OneHot, Matrix_medium_to_fine_OneHot

def margin_loss(y_true, y_pred):
    present_error_raw = torch.square(torch.clamp(0.9 - y_pred, 0.0))
    absent_error_raw = torch.square(torch.clamp(y_pred - 0.1, 0.0))
    L = torch.add(y_true * present_error_raw, 0.5 * (1.0 - y_true) * absent_error_raw)
    total_marginloss = L.sum(dim=1).mean()

    return total_marginloss


def consistency_check(y_pred_ancestor,y_pred_current,lookup_matrix,num_class_current):
    pred_max_ancestor = torch.argmax(y_pred_ancestor,dim=1).to("cpu")
    pred_max_current = torch.argmax(y_pred_current,dim=1)
    
    rows = lookup_matrix[pred_max_ancestor]
    rows = rows.to("cuda:0")

    one_hot = torch.nn.functional.one_hot(pred_max_current,num_class_current).float()
    return torch.sum(rows * one_hot, 1)

def get_consistency(y_true_ancestor, y_pred, lookup_matrix):
    '''
    Get consistency based on 2 levels
    Provide true levels for the level above, predictions for the current level and a look up matrix
    '''
    # Applying softmax to y_pred for normalization
    f = torch.nn.Softmax()
    y_prob = f(y_pred)
    
    index_for_predictions = torch.argmax(y_true_ancestor, dim=1).long()
    consistent_fine = lookup_matrix[index_for_predictions.to("cpu")] * y_prob.to("cpu")
    consistent_fine = consistent_fine.to("cuda:0")
    Consistency_sum_array = torch.sum(consistent_fine, dim=1)
    
    return torch.abs(1 - Consistency_sum_array)

def CustomLoss(y_true_c, y_true_m, y_true_f, y_pred_c, y_pred_m, y_pred_f, LW_C, LW_M, LW_F,
               number_of_classes_m, number_of_classes_f, m_one_hot, f_one_hot, C_Weight=0.2):
    
    con_m = consistency_check(y_pred_c,y_pred_m,m_one_hot,num_class_current=number_of_classes_m)
    con_m_not = torch.abs(con_m-1)
    
    con_f = consistency_check(y_pred_m,y_pred_f,f_one_hot,num_class_current=number_of_classes_f)
    con_f_not = torch.abs(con_f-1)
    
    con_sum_m = get_consistency(y_true_c,y_pred_m,m_one_hot)
    con_sum_f = get_consistency(y_true_m,y_pred_f,f_one_hot)
    
    medium_lvl_cosistency = con_sum_m * con_m_not
    fine_lvl_cosistency = con_sum_f * con_f_not
   
    ML_c = margin_loss(y_true_c, y_pred_c)*LW_C
    ML_m = LW_M*((1-C_Weight)*(margin_loss(y_true_m, y_pred_m))+C_Weight*(medium_lvl_cosistency))
    ML_f = LW_F*((1-C_Weight)*(margin_loss(y_true_f, y_pred_f))+C_Weight*(fine_lvl_cosistency))
    
    batch_loss = ML_c + ML_m + ML_f
    #print(f"batch_loss: {torch.mean(batch_loss).item()}")

    return torch.mean(batch_loss)

def CustomLoss2(y_true_c, y_true_m, y_true_f, y_pred_c, y_pred_m, y_pred_f, LW_C, LW_M, LW_F,
               number_of_classes_m, number_of_classes_f, m_one_hot, f_one_hot, C_Weight=0.2):
    
    con_m = consistency_check(y_pred_c,y_pred_m,m_one_hot,num_class_current=number_of_classes_m)
    con_m_not = torch.abs(con_m-1)
    
    con_f = consistency_check(y_pred_m,y_pred_f,f_one_hot,num_class_current=number_of_classes_f)
    con_f_not = torch.abs(con_f-1)
    
    con_sum_m = get_consistency(y_true_c,y_pred_m,m_one_hot)
    con_sum_f = get_consistency(y_true_m,y_pred_f,f_one_hot)
    
    medium_lvl_cosistency = con_sum_m * con_m_not
    fine_lvl_cosistency = con_sum_f * con_f_not  
   
    ML_c = LW_C*margin_loss(y_true_c, y_pred_c)
    ML_m = LW_M*((1-C_Weight)*(margin_loss(y_true_m, y_pred_m))+C_Weight*(medium_lvl_cosistency))
    ML_f = LW_F*((1-C_Weight)*(margin_loss(y_true_f, y_pred_f))+C_Weight*(fine_lvl_cosistency))

    return torch.mean(ML_c), torch.mean(ML_m), torch.mean(ML_f)


def mixup_data(x, y_c, y_m, y_f, alpha=0.2, device='cuda:0'):
    if alpha > 0:
        lam = np.random.beta(alpha, alpha)
    else:
        lam = 1.0
    batch_size = x.size(0)

    mixed_x = lam * x[(batch_size//2):] + (1 - lam) * x[:(batch_size//2)]
    mixed_yc = lam * y_c[(batch_size//2):] + (1 - lam) * y_c[:(batch_size//2)]
    mixed_ym = lam * y_m[(batch_size//2):] + (1 - lam) * y_m[:(batch_size//2)]
    mixed_yf = lam * y_f[(batch_size//2):] + (1 - lam) * y_f[:(batch_size//2)]

    return mixed_x, mixed_yc, mixed_ym, mixed_yf


class LexicographicEarlyStopping:
    def __init__(self, patience=10, tolerances=[0.2, 0.5, 0.0]):

        self.patience = patience
        self.tolerances = tolerances
        self.counter = 0
        self.best_metrics = None
        self.early_stop = False
        self.best_model_state = None

    def _is_better(self, current, best):

        for i in range(len(current)):
            val_curr = current[i]
            val_best = best[i]
            tol = self.tolerances[i] if i < len(self.tolerances) else 0.0

            if val_curr > val_best + tol:
                return True
        
            if val_best > val_curr + tol:
                return False
            
        return True

    def __call__(self, current_metrics, model):

        if self.best_metrics is None:
            self.best_metrics = current_metrics
            self.best_model_state = model.state_dict()
        elif self._is_better(current_metrics, self.best_metrics):
            self.best_metrics = current_metrics
            self.best_model_state = model.state_dict()
            self.counter = 0
        else:
            self.counter += 1
            if self.counter >= self.patience:
                self.early_stop = True

    def load_best_weights(self, model):
        model.load_state_dict(self.best_model_state)