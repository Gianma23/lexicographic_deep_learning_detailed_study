from datasets import CIFAR100, get_CIFAR100_dataset_manager
from hdcapsnet_cf100 import HD_CAPSNET_NS_CF100, HD_CAPSNET_NS_CF100_HALF, EarlyStopper, HD_CAPSNET_NS_CF100_NORELU, HD_CAPSNET_CF100, HD_CAPSNET_NS_CF100_LASTHF, HD_CAPSNET_NS_CF100_DOUBLE
from hdcapsnet import HD_CAPSNET_CF10
from torch.utils.data import DataLoader
from tqdm import tqdm
from metrics import hmeasurements

import torchvision.transforms as T
import torch, torch.nn as nn
import utils, config, numpy as np, random, os, statistics, matplotlib.pyplot as plt, sys

train_params = config.CIFAR100_TRAIN_PARAMS
model_params = config.CIFAR10_MODEL_PARAMS
transform = config.CIFAR100_TRANSFORM
loss_weights = config.CIFAR100_LOSS_W

train_epochs = 100
early_stopper = EarlyStopper(patience=3, min_delta=0.5)

fine_coarse2 = {
0:4,1:1,2:14,3:8,4:0,5:6,6:7,7:7,8:18,9:3,
10:3,11:14,12:9,13:18,14:7,15:11,16:3,17:9,18:7,19:11,
20:6,21:11,22:5,23:10,24:7,25:6,26:13,27:15,28:3,29:15,
30:0,31:11,32:1,33:10,34:12,35:14,36:16,37:9,38:11,39:5,
40:5,41:19,42:8,43:8,44:15,45:13,46:14,47:17,48:18,49:10,
50:16,51:4,52:17,53:4,54:2,55:0,56:17,57:4,58:18,59:17,
60:10,61:3,62:2,63:12,64:12,65:16,66:12,67:1,68:9,69:19,
70:2,71:10,72:0,73:1,74:16,75:12,76:9,77:13,78:15,79:13,
80:16,81:19,82:2,83:4,84:6,85:19,86:5,87:5,88:8,89:19,
90:18,91:1,92:2,93:15,94:6,95:0,96:17,97:8,98:14,99:13
}

coarse2_coarse1 = {
    0:0, 1:0, 2:1, 3:2, 
    4:1, 5:2, 6:2, 7:3, 
    8:4, 9:5, 10:5, 11:4, 
    12:4, 13:3, 14:6, 15:4, 
    16:4, 17:1, 18:7, 19:7
}


keys = np.array(sorted(coarse2_coarse1.keys()))
vals = np.array([coarse2_coarse1[k] for k in keys])
classes = np.array(sorted(set(vals)))
# compare values against each class to get (n_classes, n_keys)
one_hot_cm = (vals[None, :] == classes[:, None]).astype(float)

keys = np.array(sorted(fine_coarse2.keys()))
vals = np.array([fine_coarse2[k] for k in keys])
classes = np.array(sorted(set(vals)))
# compare values against each class to get (n_classes, n_keys)
one_hot_mf = (vals[None, :] == classes[:, None]).astype(float)


if __name__ == "__main__":

    model_string = sys.argv[1]
    half = ""
    if "HALF" in model_string:
        half = "HALF"
        model_s = HD_CAPSNET_NS_CF100_HALF
    elif "NORELU" in model_string:
        half = "NORELU"
        model_s = HD_CAPSNET_NS_CF100_NORELU
    elif "LASTHF" in model_string:
        half = "HALFLAST"
        model_s = HD_CAPSNET_NS_CF100_LASTHF
    elif "DOUBLE" in model_string:
        half = "DOUBLE"
        model_s = HD_CAPSNET_NS_CF100_DOUBLE
    else:
        model_s = HD_CAPSNET_NS_CF100
        #model_s = HD_CAPSNET_CF100


    loss_type = sys.argv[2]
    dw = sys.argv[3] == "True"
    dw_type = "NODW"
    if dw:
        dw_type = ""
    bias = sys.argv[4] == "True"
    bias_type = ""
    if bias:
        bias_type = "BIAS"
    loss_func = sys.argv[5]
    scale_f = ""
    scale_factor = sys.argv[6] == "True"
    if scale_factor:
        scale_f = "SCALE_FACTOR"


    path = "Images/CIFAR100_2/"
    filename = f"HD-CNN-{half}-{bias_type}-{dw_type}-{loss_type}-{loss_func}-{scale_f}-{train_epochs}-DEFINITIVE-DROP-CIFAR100"
    #filename = f"HD-CAPSNET-{dw_type}-{train_epochs}-CIFAR100"

    h1_ = []
    h2_ = []
    h0_ = []
    c_ = []
    em_ = []
    co_ = []
    me_ = []
    fi_ = []    

    for i in range(3):
        
        seed = i
        np.random.seed(seed)
        random.seed(seed)
        torch.manual_seed(seed)
        torch.cuda.manual_seed(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        os.environ["PYTHONHASHSEED"] = str(seed)

        dataset = CIFAR100()
        #dataset = get_CIFAR100_dataset_manager()
        num_classes = utils.num_classes(dataset)

        #num_classes = {
        #    "coarse" : dataset.num_classes_l0,
        #    "medium" : dataset.num_classes_l1,
        #    "fine"   : dataset.num_classes_l2
        #}
        
        perm = torch.randperm(dataset['x_train'].shape[0])
        n_train = int(0.8 * dataset['x_train'].shape[0])
        train_idx = perm[:n_train]
        val_idx = perm[n_train:]

        dataset_tr = utils.ThreeLevelDataset_CIFAR100(
            images=dataset['x_train'].permute(0, 3, 1, 2)[train_idx],
            y_coarse=dataset['y_train_coarse'][train_idx],
            y_medium=dataset['y_train_medium'][train_idx],
            y_fine=dataset['y_train_fine'][train_idx],
            transform=transform
        )

        dataset_va = utils.ThreeLevelDataset_CIFAR100(
            images=dataset['x_train'].permute(0, 3, 1, 2)[val_idx],
            y_coarse=dataset['y_train_coarse'][val_idx],
            y_medium=dataset['y_train_medium'][val_idx],
            y_fine=dataset['y_train_fine'][val_idx],
            transform=T.Compose([
                T.ToTensor(),
                T.Normalize(mean=config.CIFAR100_MEAN, std=config.CIFAR100_STD),
            ])
        )
        
        setup = utils.get_pytorch_setup(model_s, num_classes, model_params, train_params, loss_weights, dataset_tr, bias)
        c_to_m, m_to_f = utils.strange(num_classes, dataset)

        model = setup["model"].to("cuda:0")
        optimizer = setup["optimizer"]
        lr_scheduler = setup["lr_scheduler"]
        criterion = setup["class_loss_fn"]
        lw = setup["loss_weights"]
        init_lw = setup["loss_weights"]
        
        
        loader_tr = DataLoader(
            dataset_tr,
            batch_size= 32,
            shuffle=True,
            num_workers=0,
            pin_memory=True,
        )

        loader_va = DataLoader(
            dataset_va,
            batch_size= 32,
            shuffle=True,
            num_workers=0,
            pin_memory=True,
        )

        dataset_te = utils.ThreeLevelDataset_CIFAR100(
            images=dataset['x_test'].permute(0,3,1,2),
            y_coarse=dataset['y_test_coarse'],
            y_medium=dataset['y_test_medium'],
            y_fine=dataset['y_test_fine'],
            transform=T.Compose([
                T.ToTensor(),
                T.Normalize(mean=config.CIFAR100_MEAN, std=config.CIFAR100_STD),
            ])
        )

        loader_te = DataLoader(
            dataset_te,
            batch_size= 32,
            shuffle=True,
            num_workers=0,
            pin_memory=True,
        )
        

        total_loss = [[],[],[]]
        val_total_loss = [[],[],[]]
        val_total_acc = [[],[],[]]
        train_total_acc = [[],[],[]]
        completed_epochs = 0
        early_stopping = utils.LexicographicEarlyStopping(patience=10, tolerances=[0.25, 0.5, 0.0])
        bce_loss = torch.nn.BCEWithLogitsLoss(reduction="mean")
        for epoch in tqdm(range(train_epochs)):
            coarse_pos, medium_pos, fine_pos = 0,0,0
            coarse_pos_v, medium_pos_v, fine_pos_v = 0,0,0
            model.train()
            epoch_loss = [[],[],[]]
            val_loss = [[], [], []]
            labels = 0
            #for img, yc, ym, yf in dataset.train_dataset:
            for img, yc, ym, yf in loader_tr:

                img = img.to(device="cuda:0")
                yc, ym, yf = yc.to(device="cuda:0"), ym.to(device="cuda:0"), yf.to(device="cuda:0")

                img, yc, ym, yf = utils.mixup_data(img, yc, ym, yf)
                
                c_argmax = torch.argmax(yc, dim=1)
                m_argmax = torch.argmax(ym, dim=1)
                f_argmax = torch.argmax(yf, dim=1)

                optimizer.zero_grad()
                coarse_pred, medium_pred, fine_pred = model(img)

                if loss_func == "COMPLETE":
                    loss_c, loss_m, loss_f = utils.CustomLoss2(yc, ym, yf, coarse_pred, medium_pred, fine_pred, lw["coarse"], lw["medium"], lw["fine"], num_classes["medium"], num_classes["fine"], c_to_m, m_to_f)
                elif loss_func == "CE":
                    loss_c = nn.functional.cross_entropy(coarse_pred, yc)
                    loss_m = nn.functional.cross_entropy(medium_pred, ym)
                    loss_f = nn.functional.cross_entropy(fine_pred, yf)
                elif loss_func == "ML":
                    loss_c = utils.margin_loss(yc, coarse_pred)
                    loss_m = utils.margin_loss(ym, medium_pred)
                    loss_f = utils.margin_loss(yf, fine_pred)
                else:
                    raise Exception("WRONG LOSS FUNCTION")
                
                with torch.no_grad():
                    loss_cm = 0.0
                    for i, elem in enumerate(medium_pred):
                        loss_cm += bce_loss(elem, torch.from_numpy(one_hot_cm[torch.argmax(coarse_pred[i]).item()]).to("cuda:0"))
                    loss_mf = 0.0
                    for i, elem in enumerate(fine_pred):
                        loss_mf += bce_loss(elem, torch.from_numpy(one_hot_mf[torch.argmax(medium_pred[i]).item()]).to("cuda:0"))   

                epoch_loss[0].append(loss_c.item())
                epoch_loss[1].append(loss_m.item())
                epoch_loss[2].append(loss_f.item())

                if loss_type == "SINGLE": 

                    loss = loss_c + loss_m + loss_f
                    loss.backward()

                elif loss_type == "SEPARATE":

                    if scale_factor:
                        loss_cm *= 0.0004
                        loss_mf *= 0.0002
                    loss_c.backward(retain_graph = True)
                    loss_m += loss_cm
                    loss_m.backward(retain_graph = True)
                    loss_f += loss_mf
                    loss_f.backward()

                else:
                    raise Exception("WRONG LOSS TYPE")
                
                optimizer.step()
                
                c_pred, m_pred, f_pred = torch.argmax(coarse_pred, 1).to(dtype=torch.float), torch.argmax(medium_pred, 1).to(dtype=torch.float), torch.argmax(fine_pred, 1).to(dtype=torch.float)

                c_true, m_true, f_true = torch.argmax(yc, 1).to(dtype=torch.float), torch.argmax(ym, 1).to(dtype=torch.float), torch.argmax(yf, 1).to(dtype=torch.float)

                labels += len(c_true)

                for j, elem in enumerate(c_true):
                    if elem == c_pred[j]:
                        coarse_pos += 1
                for j, elem in enumerate(m_true):
                    if elem == m_pred[j]:
                        medium_pos += 1
                for j, elem in enumerate(f_true):
                    if elem == f_pred[j]:
                        fine_pos += 1

            labels_v = 0
            model.eval()
            with torch.no_grad():
                #for img, yc, ym, yf in dataset.val_dataset:
                for img, yc, ym, yf in loader_va:

                    img = img.to(device="cuda:0")
                    yc, ym, yf = yc.to(device="cuda:0"), ym.to(device="cuda:0"), yf.to(device="cuda:0")

                    coarse_pred, medium_pred, fine_pred = model(img)

                    if loss_func == "COMPLETE":
                        loss_c, loss_m, loss_f = utils.CustomLoss2(yc, ym, yf, coarse_pred, medium_pred, fine_pred, lw["coarse"], lw["medium"], lw["fine"], num_classes["medium"], num_classes["fine"], c_to_m, m_to_f)
                    elif loss_func == "CE":
                        loss_c = nn.functional.cross_entropy(coarse_pred, yc)
                        loss_m = nn.functional.cross_entropy(medium_pred, ym)
                        loss_f = nn.functional.cross_entropy(fine_pred, yf)
                    elif loss_func == "ML":
                        loss_c = utils.margin_loss(yc, coarse_pred)
                        loss_m = utils.margin_loss(ym, medium_pred)
                        loss_f = utils.margin_loss(yf, fine_pred)
                    else:
                        raise Exception("WRONG LOSS FUNCTION")

                    c_pred, m_pred, f_pred = torch.argmax(coarse_pred, 1).to(dtype=torch.float), torch.argmax(medium_pred, 1).to(dtype=torch.float), torch.argmax(fine_pred, 1).to(dtype=torch.float)

                    c_true, m_true, f_true = torch.argmax(yc, 1).to(dtype=torch.float), torch.argmax(ym, 1).to(dtype=torch.float), torch.argmax(yf, 1).to(dtype=torch.float)

                    labels_v += len(c_true)

                    val_loss[0].append(loss_c.item())
                    val_loss[1].append(loss_m.item())
                    val_loss[2].append(loss_f.item())

                    for j, elem in enumerate(c_true):
                        if elem == c_pred[j]:
                            coarse_pos_v += 1
                    for j, elem in enumerate(m_true):
                        if elem == m_pred[j]:
                            medium_pos_v += 1
                    for j, elem in enumerate(f_true):
                        if elem == f_pred[j]:
                            fine_pos_v += 1

                    validation_loss = loss_c + loss_m + loss_f

            coarse_acc = 100*coarse_pos/labels
            medium_acc = 100*medium_pos/labels
            fine_acc = 100*fine_pos/labels

            coarse_acc_v = 100*coarse_pos_v/labels_v
            medium_acc_v = 100*medium_pos_v/labels_v
            fine_acc_v = 100*fine_pos_v/labels_v
            #print(f"Coarse correct: {coarse_pos} out of {labels}, {coarse_acc}%")
            #print(f"Medium correct: {medium_pos} out of {labels}, {medium_acc}%")
            #print(f"Fine correct: {fine_pos} out of {labels}, {fine_acc}%")
            #"""
            if dw:
                new_LW = utils.lw_modifier(init_lw, [coarse_pos_v/labels, medium_pos_v/labels, fine_pos_v/labels])

                lw["coarse"] = new_LW[0]
                lw["medium"] = new_LW[1]
                lw["fine"] = new_LW[2]

            l_c = statistics.mean(epoch_loss[0])
            l_m = statistics.mean(epoch_loss[1])
            l_f = statistics.mean(epoch_loss[2])
            if l_c > l_m or l_m > l_f:
              print("Logical Error")
            print(f"Epoch {epoch}: C: {l_c}, M: {l_m}, F: {l_f}")
            total_loss[0].append(statistics.mean(epoch_loss[0]))
            total_loss[1].append(statistics.mean(epoch_loss[1]))
            total_loss[2].append(statistics.mean(epoch_loss[2]))

            val_total_loss[0].append(statistics.mean(val_loss[0]))
            val_total_loss[1].append(statistics.mean(val_loss[1]))
            val_total_loss[2].append(statistics.mean(val_loss[2]))

            train_total_acc[0].append(coarse_acc)
            train_total_acc[1].append(medium_acc)
            train_total_acc[2].append(fine_acc)

            val_total_acc[0].append(coarse_acc_v)
            val_total_acc[1].append(medium_acc_v)
            val_total_acc[2].append(fine_acc_v)
            completed_epochs += 1

            print(f"Epoch {epoch}: C: {coarse_acc_v}, M: {medium_acc_v}, F: {fine_acc_v}")
            val_metrics = [coarse_acc_v, medium_acc_v, fine_acc_v]
            early_stopping(val_metrics, model)

            #if early_stopping.early_stop:
            #    print("Early stopping triggered.")
            #    break

            lr_scheduler.step()
        """
        #print(total_loss)
        x_ax = [i for i in range(completed_epochs)]
        plt.plot(x_ax, total_loss[0], label="loss coarse")
        plt.plot(x_ax, total_loss[1], '-.', label="loss medium")
        plt.plot(x_ax, total_loss[2], '-', label="loss fine")
        plt.xlabel("Epoch")
        plt.ylabel("Loss")
        plt.legend()
        plt.title('HD-CNN-NS Train Losses')
        plt.savefig(f"TRAINL.png")
        plt.close()
        
        x_ax = [i for i in range(completed_epochs)]
        plt.plot(x_ax, val_total_loss[0], label="loss coarse")
        plt.plot(x_ax, val_total_loss[1], '-.', label="loss medium")
        plt.plot(x_ax, val_total_loss[2], '-', label="loss fine")
        plt.xlabel("Epoch")
        plt.ylabel("Loss")
        plt.legend()
        plt.title('HD-CNN-NS Validation Losses')
        #plt.savefig(f"{path}{filename}_VAL.png")
        plt.close()

        x_ax = [i for i in range(completed_epochs)]
        plt.plot(x_ax, train_total_acc[0], label="acc coarse")
        plt.plot(x_ax, train_total_acc[1], '-.', label="acc medium")
        plt.plot(x_ax, train_total_acc[2], '-', label="acc fine")
        plt.xlabel("Epoch")
        plt.ylabel("Accuracy")
        plt.legend()
        plt.title('HD-CNN-NS Train Accuracies')
        #plt.savefig(f"{path}{filename}_TRAIN_ACC.png")
        plt.close()

        x_ax = [i for i in range(completed_epochs)]
        plt.plot(x_ax, val_total_acc[0], label="acc coarse")
        plt.plot(x_ax, val_total_acc[1], '-.', label="acc medium")
        plt.plot(x_ax, val_total_acc[2], '-', label="acc fine")
        plt.xlabel("Epoch")
        plt.ylabel("Accuracy")
        plt.legend()
        plt.title('HD-CNN-NS Validation Accuracies')
        plt.savefig(f"VAL_ACC.png")
        plt.close()
        
        x_ax = [i for i in range(len(train_dict["coarse"].keys()))]
        data = [train_dict["coarse"][i] for i in range(num_classes["coarse"])]
        plt.bar(x_ax, data)
        plt.xlabel("Class")
        plt.ylabel("Number of elements")
        plt.title("Coarse class train distribution")
        plt.savefig(f"Images/Dataset/Train_coarse.png")
        plt.close()

        x_ax = [i for i in range(len(val_dict["coarse"].keys()))]
        data = [val_dict["coarse"][i] for i in range(num_classes["coarse"])]
        plt.bar(x_ax, data)
        plt.xlabel("Class")
        plt.ylabel("Number of elements")
        plt.title("Coarse class validation distribution")
        plt.savefig(f"Images/Dataset/Val_coarse.png")
        plt.close()

        x_ax = [i for i in range(len(train_dict["medium"].keys()))]
        data = [train_dict["medium"][i] for i in range(num_classes["medium"])]
        plt.bar(x_ax, data)
        plt.xlabel("Class")
        plt.ylabel("Number of elements")
        plt.title("Medium class train distribution")
        plt.savefig(f"Images/Dataset/Train_medium.png")
        plt.close()

        x_ax = [i for i in range(len(val_dict["medium"].keys()))]
        data = [val_dict["medium"][i] for i in range(num_classes["medium"])]
        plt.bar(x_ax, data)
        plt.xlabel("Class")
        plt.ylabel("Number of elements")
        plt.title("Medium class validation distribution")
        plt.savefig(f"Images/Dataset/Val_medium.png")
        plt.close()

        x_ax = [i for i in range(len(train_dict["fine"].keys()))]
        data = [train_dict["fine"][i] for i in range(num_classes["fine"])]
        plt.bar(x_ax, data)
        plt.xlabel("Class")
        plt.ylabel("Number of elements")
        plt.title("Fine class train distribution")
        plt.savefig(f"Images/Dataset/Train_fine.png")
        plt.close()

        x_ax = [i for i in range(len(val_dict["fine"].keys()))]
        data = [val_dict["fine"][i] for i in range(num_classes["fine"])]
        plt.bar(x_ax, data)
        plt.xlabel("Class")
        plt.ylabel("Number of elements")
        plt.title("Fine class validation distribution")
        plt.savefig(f"Images/Dataset/Val_fine.png")
        plt.close()
        """
    #"""

        coarse_pos, medium_pos, fine_pos = 0,0,0

        true_label_c, true_label_m, true_label_f = [], [], []
        pred_label_c, pred_label_m, pred_label_f = [], [], []

        early_stopping.load_best_weights(model)
        model.eval()
        with torch.no_grad():
            #for img, yc, ym, yf in dataset.test_dataset:
            for img, yc, ym, yf in loader_te:
                img = img.to(device="cuda:0")
                yc, ym, yf = yc.to(device="cuda:0"), ym.to(device="cuda:0"), yf.to(device="cuda:0")

                coarse_pred, medium_pred, fine_pred = model(img)

                y_true_c = torch.argmax(yc, 1)
                y_true_m = torch.argmax(ym, 1)
                y_true_f = torch.argmax(yf, 1)

                c_pred = torch.argmax(coarse_pred, 1)
                m_pred = torch.argmax(medium_pred, 1)
                f_pred = torch.argmax(fine_pred, 1)

                true_label_c.append(yc.detach().cpu())
                true_label_m.append(ym.detach().cpu())
                true_label_f.append(yf.detach().cpu())

                pred_label_c.append(coarse_pred.detach().cpu())
                pred_label_m.append(medium_pred.detach().cpu())
                pred_label_f.append(fine_pred.detach().cpu())

                for j, elem in enumerate(y_true_c):
                    if elem == c_pred[j]:
                        coarse_pos += 1
                for j, elem in enumerate(y_true_m):
                    if elem == m_pred[j]:
                        medium_pos += 1
                for j, elem in enumerate(y_true_f):
                    if elem == f_pred[j]:
                        fine_pos += 1

        true_label_c = torch.cat(true_label_c)
        true_label_m = torch.cat(true_label_m)
        true_label_f = torch.cat(true_label_f)
        pred_label_c = torch.cat(pred_label_c)
        pred_label_m = torch.cat(pred_label_m)
        pred_label_f = torch.cat(pred_label_f)

        true_label = [true_label_c, true_label_m, true_label_f]
        pred_label = [pred_label_c, pred_label_m, pred_label_f]

        h_measurements,consistency,exact_match = hmeasurements(true_label,
                                            pred_label,
                                            dataset['tree'])
                                            #dataset.tree)
        print('\nHierarchical Precision =',h_measurements[0],
            '\nHierarchical Recall =', h_measurements[1],
            '\nHierarchical F1-Score =',h_measurements[2],
            '\n Consistency = ', consistency,
            '\n Exact Match = ', exact_match,
            )    

        print(100*coarse_pos/len(true_label_c))
        print(100*medium_pos/len(true_label_c))
        print(100*fine_pos/len(true_label_c))

        h0_.append(h_measurements[0])
        h1_.append(h_measurements[1])
        h2_.append(h_measurements[2])
        c_.append(consistency)
        em_.append(exact_match)
        co_.append(100*coarse_pos/len(true_label_c))
        me_.append(100*medium_pos/len(true_label_c))
        fi_.append(100*fine_pos/len(true_label_c))


        #with open("CIFAR100_RESULTS_SCRIPT_D.txt", "a") as f:
        #    f.write(f"{filename}\n")
        #    f.write(
        #        f"Hierarchical Precision = {h_measurements[0]}\n"
        #        f"Hierarchical Recall = {h_measurements[1]}\n"
        #        f"Hierarchical F1-Score = {h_measurements[2]}\n"
        #        f"Consistency = {consistency}\n"
        #        f"Exact Match = {exact_match}\n"
        #        f"Coarse accuracy = {100 * coarse_pos / len(dataset['y_test_coarse']):.2f}\n"
        #        f"Medium accuracy = {100 * medium_pos / len(dataset['y_test_medium']):.2f}\n"
        #        f"Fine accuracy = {100 * fine_pos / len(dataset['y_test_fine']):.2f}\n\n"
        #    )

    print(f"H_P mean: {statistics.mean(h0_)}, deviation: {statistics.stdev(h0_)}")
    print(f"H_R mean: {statistics.mean(h1_)}, deviation: {statistics.stdev(h1_)}")
    print(f"H_F1 mean: {statistics.mean(h2_)}, deviation: {statistics.stdev(h2_)}")
    print(f"C mean: {statistics.mean(c_)}, deviation: {statistics.stdev(c_)}")
    print(f"EM mean: {statistics.mean(em_)}, deviation: {statistics.stdev(em_)}")
    print(f"CO mean: {statistics.mean(co_)}, deviation: {statistics.stdev(co_)}")
    print(f"ME mean: {statistics.mean(me_)}, deviation: {statistics.stdev(me_)}")
    print(f"FI mean: {statistics.mean(fi_)}, deviation: {statistics.stdev(fi_)}")

    ###############################################################################################################
    ###############################################################################################################
    ###############################################################################################################
