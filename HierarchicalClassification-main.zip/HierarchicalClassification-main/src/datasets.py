import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
import torchvision
import torchvision.datasets as dataset
import torchvision.transforms as transforms
import torchvision.transforms.functional as Fn
import torch.nn.functional as F
from treelib import Tree
import pandas as pd
from sklearn.model_selection import train_test_split
import urllib.request
from torch.utils.data import Dataset

import os
import csv
from typing import List, Dict, Optional, Tuple
from PIL import Image
from collections import defaultdict

def to_categorical(y, num_classes):
    """ 1-hot encodes a tensor """
    return np.eye(num_classes, dtype='uint8')[y]

def DatasetTree(level_maps):
    """
    provide levels maps as a list of class level map, prioritising from coarse to fine levels.
    Works only for hierarchy with 2 and 3 levels.
    """
    levels = len(level_maps)
    
    tree = Tree()
    tree.create_node("Root", "root")  # root node

        
    tree = Tree()
    tree.create_node("Root", "root")  # root node
    
    if levels == 1:
        for i in range(len(set(level_maps[0].values()))):
            tree.create_node('Coarse_'+str(i), 'L0_'+ str(i), parent="root")
            for j in range(len(level_maps[0])):
                if level_maps[0][j] == i :
                    tree.create_node('Fine_'+str(j), 'L1_'+str(j), 'L0_'+ str(i))
                    
    elif levels == 2:
        for i in range(len(set(level_maps[0].values()))):
            tree.create_node('Coarse_'+str(i), 'L0_'+ str(i), parent="root")
            for j in range(len(level_maps[0])):
                if level_maps[0][j] == i :
                    tree.create_node('Medium'+str(j), 'L1_'+str(j), 'L0_'+ str(i))
                    for k in range(len(level_maps[1])):
                        if level_maps[1][k] == j :
                            tree.create_node('Fine_'+str(k), 'L2_'+str(k), 'L1_'+ str(j))

    return tree


def get_tree(taxonomy, labels):
    """
    This method draws the taxonomy using the graphviz library.
    :return:
    :rtype: Digraph
     """
    tree = Tree()
    tree.create_node("Root", "root")  # root node
    
    if len(taxonomy) > 1:
        for i in range(len(taxonomy[0])):
            tree.create_node(labels[0][i] + ' -> (L0_' + str(i) + ')', 'L0_' + str(i), parent="root")

        for l in range(len(taxonomy)):
            for i in range(len(taxonomy[l])):
                for j in range(len(taxonomy[l][i])):
                    if taxonomy[l][i][j] == 1:
                        tree.create_node(labels[l + 1][j] + ' -> (L' + str(l + 1) + '_' + str(j) + ')',
                                         'L' + str(l + 1) + '_' + str(j),
                                         parent='L' + str(l) + '_' + str(i))
    if len(taxonomy) == 1:
        for i in range(len(labels[0])):
            tree.create_node(labels[0][i] + ' -> (L0_' + str(i) + ')', 'L0_' + str(i), parent="root")

    return tree


def F_MNIST(version : str = 'ALL'):
    
    F_MNIST_TR = dataset.FashionMNIST("", download=True, train=True, transform=transforms.Compose([transforms.ToTensor()]))
    F_MNIST_TE = dataset.FashionMNIST("", download=True, train=False, transform=transforms.Compose([transforms.ToTensor()]))


    x_train, y_train = F_MNIST_TR.data, F_MNIST_TR.targets
    x_test, y_test = F_MNIST_TE.data, F_MNIST_TE.targets

    #--- coarse 1 classes ---
    num_coarse_1 = 2
    #--- coarse 2 classes ---
    num_coarse_2 = 6
    #--- fine classes ---
    num_fine  = 10
    #-------------------- data loading ----------------------
    x_train = x_train.to(torch.float32)
    x_test = x_test.to(torch.float32)

    y_train_fine = to_categorical(y_train, num_fine)
    y_test_fine = to_categorical(y_test, num_fine)

    x_train = x_train.reshape(-1, 28, 28, 1).to(torch.float32) / 255.
    x_test = x_test.reshape(-1, 28, 28, 1).to(torch.float32) / 255.
    #---------------- data preprocessiong -------------------
    #x_train = (x_train-torch.mean(x_train)) / torch.std(x_train)
    #x_test = (x_test-torch.mean(x_test)) / torch.std(x_test)
    #---------------------- make coarse 2 labels --------------------------
    fine_coarse2 = {0:0, 1:1, 2:0, 3:2, 4:3, 5:5, 6:0, 7:5, 8:4, 9:5}
    y_train_coarse2 = np.zeros((y_train_fine.shape[0], num_coarse_2)).astype("float32")
    y_test_coarse2 = np.zeros((y_test_fine.shape[0], num_coarse_2)).astype("float32")
    for i in range(y_train_coarse2.shape[0]):
      y_train_coarse2[i][fine_coarse2[np.argmax(y_train_fine[i])]] = 1.0
    for i in range(y_test_coarse2.shape[0]):
      y_test_coarse2[i][fine_coarse2[np.argmax(y_test_fine[i])]] = 1.0
    #---------------------- make coarse 1 labels --------------------------
    coarse2_coarse1 = {0:0, 1:0, 2:0, 3:0, 4:1, 5:1}
    y_train_coarse1 = np.zeros((y_train_coarse2.shape[0], num_coarse_1)).astype("float32")
    y_test_coarse1 = np.zeros((y_test_coarse2.shape[0], num_coarse_1)).astype("float32")
    for i in range(y_train_coarse1.shape[0]):
      y_train_coarse1[i][coarse2_coarse1[np.argmax(y_train_coarse2[i])]] = 1.0
    for i in range(y_test_coarse1.shape[0]):
      y_test_coarse1[i][coarse2_coarse1[np.argmax(y_test_coarse2[i])]] = 1.0

    tree = DatasetTree([coarse2_coarse1, fine_coarse2])

    if version == 'reduce':
        x_train = x_train[:1000]
        y_train_fine = y_train_fine[:1000]
        y_train_coarse2 = y_train_coarse2[:1000]
        y_train_coarse1 = y_train_coarse1[:1000]

        x_test = x_test[:100]
        y_test_fine = y_test_fine[:100]
        y_test_coarse2 = y_test_coarse2[:100]
        y_test_coarse1 = y_test_coarse1[:100]
        print('Using reduced Fashion-MNIST dataset: Training have 1000 samples and testing have 100 samples')
    else:
        print('Fashion-MNIST dataset: Training have 60,000 samples and testing have 10,000 samples')
        
    return {'x_train':x_train, 'y_train_coarse':y_train_coarse1, 'y_train_medium':y_train_coarse2, 'y_train_fine':y_train_fine, 'x_test':x_test, 'y_test_coarse':y_test_coarse1, 'y_test_medium':y_test_coarse2, 'y_test_fine':y_test_fine, 'tree':tree, 'name': 'FMNIST'}


def CIFAR10(version : str = 'ALL'):

    CIFAR10_TR = dataset.CIFAR10("data", download=True, train=True, transform=transforms.Compose([transforms.ToTensor()]))
    CIFAR10_TE = dataset.CIFAR10("data", download=True, train=False, transform=transforms.Compose([transforms.ToTensor()]))

    x_train, y_train = CIFAR10_TR.data, CIFAR10_TR.targets
    x_test, y_test = CIFAR10_TE.data, CIFAR10_TE.targets

    #--- coarse 1 classes ---
    num_coarse_1 = 2
    #--- coarse 2 classes ---
    num_coarse_2 = 7
    #--- fine classes ---
    num_fine  = 10

    #-------------------- data loading ----------------------
    x_train = torch.from_numpy(x_train)
    x_test = torch.from_numpy(x_test)

    x_train = x_train.to(torch.float32)
    x_test = x_test.to(torch.float32)

    y_train_fine = to_categorical(y_train, num_fine)
    y_test_fine = to_categorical(y_test, num_fine)

    #---------------- data preprocessiong -------------------
    #x_train = (x_train-torch.mean(x_train)) / torch.std(x_train)
    #x_test = (x_test-torch.mean(x_test)) / torch.std(x_test)

    #---------------------- make coarse 2 labels --------------------------
    fine_coarse2 = {
      2:3, 3:5, 5:5,
      1:2, 7:6, 4:6,
      0:0, 6:4, 8:1, 9:2
    }
    y_train_coarse2 = np.zeros((y_train_fine.shape[0], num_coarse_2)).astype("float32")
    y_test_coarse2 = np.zeros((y_test_fine.shape[0], num_coarse_2)).astype("float32")
    for i in range(y_train_coarse2.shape[0]):
      y_train_coarse2[i][fine_coarse2[np.argmax(y_train_fine[i])]] = 1.0
    for i in range(y_test_coarse2.shape[0]):
      y_test_coarse2[i][fine_coarse2[np.argmax(y_test_fine[i])]] = 1.0
      
    #---------------------- make coarse 1 labels --------------------------
    coarse2_coarse1 = {
      0:0, 1:0, 2:0,
      3:1, 4:1, 5:1, 6:1
    }
    y_train_coarse1 = np.zeros((y_train_coarse2.shape[0], num_coarse_1)).astype("float32")
    y_test_coarse1 = np.zeros((y_test_coarse2.shape[0], num_coarse_1)).astype("float32")
    for i in range(y_train_coarse1.shape[0]):
      y_train_coarse1[i][coarse2_coarse1[np.argmax(y_train_coarse2[i])]] = 1.0
    for i in range(y_test_coarse1.shape[0]):
      y_test_coarse1[i][coarse2_coarse1[np.argmax(y_test_coarse2[i])]] = 1.0

    tree = DatasetTree([coarse2_coarse1, fine_coarse2])

    if version == 'reduce':
        x_train = x_train[:1000]
        y_train_fine = y_train_fine[:1000]
        y_train_coarse2 = y_train_coarse2[:1000]
        y_train_coarse1 = y_train_coarse1[:1000]

        x_test = x_test[:100]
        y_test_fine = y_test_fine[:100]
        y_test_coarse2 = y_test_coarse2[:100]
        y_test_coarse1 = y_test_coarse1[:100]
        print('Using reduced CIFAR-10 dataset: Training have 1000 samples and testing have 100 samples')
    else:
        print('CIFAR-10 dataset: Training have 50,000 samples and testing have 10,000 samples')
        
    return {'x_train':x_train, 'y_train_coarse':y_train_coarse1, 'y_train_medium':y_train_coarse2, 'y_train_fine':y_train_fine, 'x_test':x_test, 'y_test_coarse':y_test_coarse1, 'y_test_medium':y_test_coarse2, 'y_test_fine':y_test_fine, 'tree':tree, 'name': 'CIFAR-10'}


def CIFAR100(version : str = 'ALL'):
    CIFAR100_TR = dataset.CIFAR100("data", download=True, train=True, transform=transforms.Compose([transforms.ToTensor()]))
    CIFAR100_TE = dataset.CIFAR100("data", download=True, train=False, transform=transforms.Compose([transforms.ToTensor()]))

    x_train, y_train = CIFAR100_TR.data, CIFAR100_TR.targets
    x_test, y_test = CIFAR100_TE.data, CIFAR100_TE.targets

    #--- coarse 1 classes ---
    num_coarse_1 = 8
    #--- coarse 2 classes ---
    num_coarse_2 = 20
    #--- fine classes ---
    num_fine  = 100

    #-------------------- data loading ----------------------
    x_train = torch.from_numpy(x_train)
    x_test = torch.from_numpy(x_test)

    x_train = x_train.to(torch.float32)
    x_test = x_test.to(torch.float32)

    y_train_fine = to_categorical(y_train, num_fine)
    y_test_fine = to_categorical(y_test, num_fine)

    #---------------- data preprocessiong -------------------
    #x_train = (x_train-np.mean(x_train)) / np.std(x_train)
    #x_test = (x_test-np.mean(x_test)) / np.std(x_test)

    fine_coarse2 = {
    0:4,1:1,2:14,3:8,4:0,5:6,6:7,7:7,8:18,9:3,
    10:3,11:14,12:9,13:18,14:7,15:11,16:3,17:9,18:7,19:11,
    20:6,21:11,22:5,23:10,24:7,25:6,26:13,27:15,28:3,29:15,
    30:0,31:11,32:1,33:10,34:12,35:14,36:16,37:9,38:11,39:5,
    40:5,41:19,42:8,43:8,44:15,45:13,46:14,47:17,48:18,49:10,
    50:16,51:4,52:17,53:4,54:2,55:0,56:17,57:4,58:18,59:17,
    60:10,61:3,62:2,63:12,64:12,65:16,66:12,67:1,68:9,69:19,
    70:2,71:10,72:0,73:1,74:16,75:12,76:9,77:13,78:15,79:13,
    80:16,81:19,82:2,83:4,84:6,85:19,86:5,87:5,88:8,89:19,
    90:18,91:1,92:2,93:15,94:6,95:0,96:17,97:8,98:14,99:13
    }
    y_train_coarse2 = np.zeros((y_train_fine.shape[0], num_coarse_2)).astype("float32")
    y_test_coarse2 = np.zeros((y_test_fine.shape[0], num_coarse_2)).astype("float32")
    for i in range(y_train_coarse2.shape[0]):
      y_train_coarse2[i][fine_coarse2[np.argmax(y_train_fine[i])]] = 1.0
    for i in range(y_test_coarse2.shape[0]):
      y_test_coarse2[i][fine_coarse2[np.argmax(y_test_fine[i])]] = 1.0
      
    #---------------------- make coarse 1 labels --------------------------
    coarse2_coarse1 = {
      0:0, 1:0, 2:1, 3:2, 
      4:1, 5:2, 6:2, 7:3, 
      8:4, 9:5, 10:5, 11:4, 
      12:4, 13:3, 14:6, 15:4, 
      16:4, 17:1, 18:7, 19:7
    }
    y_train_coarse1 = np.zeros((y_train_coarse2.shape[0], num_coarse_1)).astype("float32")
    y_test_coarse1 = np.zeros((y_test_coarse2.shape[0], num_coarse_1)).astype("float32")
    for i in range(y_train_coarse1.shape[0]):
      y_train_coarse1[i][coarse2_coarse1[np.argmax(y_train_coarse2[i])]] = 1.0
    for i in range(y_test_coarse1.shape[0]):
      y_test_coarse1[i][coarse2_coarse1[np.argmax(y_test_coarse2[i])]] = 1.0
      
    tree = DatasetTree([coarse2_coarse1, fine_coarse2])

    if version == 'reduce':
        x_train = x_train[:1000]
        y_train_fine = y_train_fine[:1000]
        y_train_coarse2 = y_train_coarse2[:1000]
        y_train_coarse1 = y_train_coarse1[:1000]

        x_test = x_test[:100]
        y_test_fine = y_test_fine[:100]
        y_test_coarse2 = y_test_coarse2[:100]
        y_test_coarse1 = y_test_coarse1[:100]
        print('Using reduced CIFAR-100 dataset: Training have 1000 samples and testing have 100 samples')
    else:
        print('CIFAR-100 dataset: Training have 50,000 samples and testing have 10,000 samples')
        
    return {'x_train':x_train, 'y_train_coarse':y_train_coarse1, 'y_train_medium':y_train_coarse2, 'y_train_fine':y_train_fine, 'x_test':x_test, 'y_test_coarse':y_test_coarse1, 'y_test_medium':y_test_coarse2, 'y_test_fine':y_test_fine, 'tree':tree, 'name': 'CIFAR-100'}

##############################################################################################################################
##############################################################################################################################
##############################################################################################################################

#
class Marine_Dataset:
    def __init__(self, name, dataset_path, train_labels_path, test_labels_path, output_level, 
                 image_size=(64, 64), batch_size=32, 
                 data_normalizing='normalize', class_encoding='One_Hot_Encoder',
                 data_augmentation='mixup', mixup_alpha=0.2):
        
        self.name = name
        self.image_size_ = image_size
        self.batch_size = batch_size
        self.dataset_path = dataset_path
        self.output_level = output_level
        self.class_encoding = class_encoding
        self.data_normalizing = data_normalizing
        self.data_augmentation = data_augmentation
        self.mixup_alpha = mixup_alpha
        
        train_labels_df = pd.read_csv(train_labels_path, sep=",", header=0)
        train_labels_df = train_labels_df.sample(frac=1).reset_index(drop=True)
        
        self.test_labels_df = pd.read_csv(test_labels_path, sep=",", header=0)
        self.test_labels_df = self.test_labels_df.sample(frac=1, random_state=1).reset_index(drop=True)
        
        self.num_classes_l0 = len(set(train_labels_df['class_level_0']))
        self.num_classes_l1 = len(set(train_labels_df['class_level_1']))
        self.num_classes_l2 = len(set(train_labels_df['class_level_2']))
        self.num_classes_l3 = len(set(train_labels_df['class_level_3']))
        self.num_classes_l4 = len(set(train_labels_df['class_level_4']))
        
        seed = os.environ.get("PYTHONHASHSEED")
        self.train_labels_df, self.val_labels_df = train_test_split(
            train_labels_df, test_size=0.12, random_state=(int(seed) + 40), 
            stratify=train_labels_df['class_level_4']
        )
        
        self.train_dataset = self.get_pipeline(self.train_labels_df, output_level)
        self.val_dataset   = self.get_pipeline(self.val_labels_df, output_level)
        self.test_dataset  = self.get_pipeline(self.test_labels_df, output_level)

        m0 = torch.zeros((self.num_classes_l0, self.num_classes_l1))
        m1 = torch.zeros((self.num_classes_l1, self.num_classes_l2))
        
        for _, row in train_labels_df.iterrows():
            m0[row['class_level_0'], row['class_level_1']] = 1.0
            m1[row['class_level_1'], row['class_level_2']] = 1.0
            
        self.Matrix_coarse_to_medium_OneHot = m0.float()
        self.Matrix_medium_to_fine_OneHot = m1.float()

        coarse2_coarse1 = dict(zip(
            train_labels_df['class_level_1'], 
            train_labels_df['class_level_0']
        ))

        fine_coarse2 = dict(zip(
            train_labels_df['class_level_2'], 
            train_labels_df['class_level_1']
        ))


        self.tree = DatasetTree([coarse2_coarse1, fine_coarse2])

    def c2_reinforce(self, parent_logits, child_reinforcer):

        return torch.matmul(parent_logits, self.Matrix_coarse_to_medium_OneHot.to("cuda:0"))

    def c3_reinforce(self, parent_logits, child_reinforcer):

        return torch.matmul(parent_logits, self.Matrix_medium_to_fine_OneHot.to("cuda:0"))

    def get_pipeline(self, dataframe, output_level):
        """
        Creates the DataLoader using the helper MarineSubDataset class.
        """
        num_classes_list = [
            self.num_classes_l0, self.num_classes_l1, self.num_classes_l2, 
            self.num_classes_l3, self.num_classes_l4
        ]

        # Instantiate the specific PyTorch Dataset (defined in previous turn)
        dataset = MarineSubDataset(
            dataframe=dataframe,
            dataset_path=self.dataset_path,
            image_size=self.image_size_,
            num_classes_list=num_classes_list,
            output_level=output_level,
            encoding_type=self.class_encoding,
            normalizer=self.data_normalizing
        )

        # Instantiate DataLoader
        loader = torch.utils.data.DataLoader(
            dataset,
            batch_size=self.batch_size,
            shuffle=True,
            num_workers=os.cpu_count() if os.cpu_count() is not None else 0,
            pin_memory=True
        )
        
        return loader


class MarineSubDataset(Dataset):
    def __init__(self, dataframe, dataset_path, image_size, 
                 num_classes_list, output_level, encoding_type, normalizer):
        self.dataframe = dataframe.reset_index(drop=True)
        self.dataset_path = dataset_path
        self.image_size = image_size  # Expected as (H, W)
        self.num_classes_list = num_classes_list # [l0, l1, l2, l3, l4]
        self.output_level = output_level
        self.encoding_type = encoding_type
        self.normalizer = normalizer
        
        # Pre-compute paths to avoid string concatenation in the loop
        self.img_paths = [os.path.join(self.dataset_path, 'marine_images', x) 
                          for x in self.dataframe['fname']]

    def __len__(self):
        return len(self.dataframe)

    def __getitem__(self, idx):
        img_path = self.img_paths[idx]
        img = torchvision.io.read_image(img_path, mode=torchvision.io.ImageReadMode.RGB)
        img = img.float() / 255.0
        img = Fn.resize(img, self.image_size, antialias=True)
        
        if self.normalizer == 'normalize':
            img = Fn.normalize(img, mean = [0.3212, 0.4310, 0.3176], std = [0.0975, 0.1109, 0.0926])

        row = self.dataframe.iloc[idx]
        c0, c1, c2 = row['class_level_0'], row['class_level_1'], row['class_level_2']
        c3, c4 = row['class_level_3'], row['class_level_4']

        if self.encoding_type == 'One_Hot_Encoder':
            l0 = F.one_hot(torch.tensor(c0).long(), num_classes=self.num_classes_list[0]).float()
            l1 = F.one_hot(torch.tensor(c1).long(), num_classes=self.num_classes_list[1]).float()
            l2 = F.one_hot(torch.tensor(c2).long(), num_classes=self.num_classes_list[2]).float()
            l3 = F.one_hot(torch.tensor(c3).long(), num_classes=self.num_classes_list[3]).float()
            l4 = F.one_hot(torch.tensor(c4).long(), num_classes=self.num_classes_list[4]).float()
        else:
            l0, l1, l2, l3, l4 = c0, c1, c2, c3, c4

        
        if self.output_level == 'only_level_3':
            return img, l2
        
        elif self.output_level == 'level_depth_3':
            return img, l0, l1, l2
        
        elif self.output_level == 'level_depth_5':
            return img, l0, l1, l2, l3, l4
        
        return img, l2 # Default fallback


def get_Marine_dataset(output_level, dataset_path: str, image_size=(64, 64), batch_size=32, 
                    subtype='Combined', data_normalizing='normalize', 
                    class_encoding='One_Hot_Encoder', data_augmentation='mixup', 
                    mixup_alpha=0.2):
    """
    Factory function to create the Marine_Dataset manager.
    """
    
    if subtype == 'Tropical':
        suffix = '_trop.csv'
    elif subtype == 'Temperate':
        suffix = '_temp.csv'
    else: # Combined
        suffix = '_comb.csv'

    train_filename = f'train_labels{suffix}'
    test_filename = f'test_labels{suffix}'
    
    train_labels_path = os.path.join(dataset_path, train_filename)
    test_labels_path = os.path.join(dataset_path, test_filename)

    dataset_name = f'Marine_dataset_{subtype}'

    return Marine_Dataset(
        name=dataset_name,
        dataset_path=dataset_path,
        train_labels_path=train_labels_path,
        test_labels_path=test_labels_path,
        output_level=output_level,
        image_size=image_size,
        batch_size=batch_size,
        data_normalizing=data_normalizing,
        class_encoding=class_encoding,
        data_augmentation=data_augmentation,
        mixup_alpha=mixup_alpha
    )